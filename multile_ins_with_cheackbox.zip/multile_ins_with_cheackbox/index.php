
<!DOCTYPE HTML>  
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Multiple data insert With Checkbox</title>
  <link rel="stylesheet" href="css/style.css"/>

</head>
<body>  

<?php
	 
include("sq_connection.php");
	   

    if(isset($_POST["submit"])){
	    
	    $uname =$_POST["uname"];
		$eml =$_POST["eml"];
		$city =$_POST["city"];
		$mess =$_POST["mess"];
		@$gender =$_POST["gender"];
		@$lang =$_POST["language"];
        @$language=implode(",",$lang);		
		 
		$query="INSERT INTO person(uname, eml, city, mess, gender, language) VALUES ('$uname','$eml','$city','$mess','$gender','$language')";
		mysqli_query($con, $query);
		
		echo "<script>alert('Data has been submited!');</script>";
	}
    else{ 
	     if(!isset($_POST["submit"])){
		echo "<script>alert('Data has not submited');</script>";
		 }
	}	
		
?>

<h2>Multiple Data Insert With Checkbox!</h2>

<form align="center" method="post" action="index.php" >  
  Name: <input type="text" name="uname" placeholder="Only Name" autocomplete="off">
  <br><br>
  E-mail: <input type="text" name="eml" placeholder="Only Email" autocomplete="off">
  <br><br>
  City name:<select  name="city">
     <option value=""> Select any city</option>
	 <option value="Delhi"> Delhi</option>
	 	 <option value="Kolkata"> Kolkata</option>
		 	 <option value="Ranchi"> Ranchi</option>
			 	 <option value="Mumbai"> Mumbai</option>
				<option value="Hydrabd"> Hydrabad</option>
             <option value="Bangolor"> Bangolor</option>
         <option value="Chenai"> Chenai</option>
    <option value="Patna">Patna</option>		 
  </select>
  <br><br>
  Comment: <textarea name="mess" rows="5" cols="40"  placeholder="please type some texte here..............."></textarea>
  <br><br>
  Gender:
  <input type="radio" name="gender" <?php if (isset($gender) && $gender=="Female") echo "checked";?> value="Female">Female
  <input type="radio" name="gender" <?php if (isset($gender) && $gender=="Male") echo "checked";?> value="Male">Male
  <input type="radio" name="gender" <?php if (isset($gender) && $gender=="Other") echo "checked";?> value="Other">Other  
  <br><br>
  <p style="color:red;">Select Lang Now Below:</p>
  <input type="checkbox" name="language[]" value="English">English
  <input type="checkbox" name="language[]" value="Hindi">Hindi
  <input type="checkbox" name="language[]" value="Bangala">Bangala
  <input type="checkbox" name="language[]" value="Telgue">Telgue   
  <input type="checkbox" name="language[]" value="Punjabi">Punjabi
  <input type="checkbox" name="language[]" value="Marathi">Marathi
  <input type="checkbox" name="language[]" value="Kunude">Kunude  
  <br><br>
  <input type="submit" name="submit" value="Submit" id="sub"> 
</form>
</body>
</html>