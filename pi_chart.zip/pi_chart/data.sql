-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 07, 2020 at 06:47 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mini_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `data`
--

DROP TABLE IF EXISTS `data`;
CREATE TABLE IF NOT EXISTS `data` (
  `dada_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `conf_pass` varchar(50) NOT NULL,
  `city_name` varchar(50) NOT NULL,
  `mob_n` varchar(12) NOT NULL,
  `gender` varchar(10) NOT NULL,
  PRIMARY KEY (`dada_id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `data`
--

INSERT INTO `data` (`dada_id`, `name`, `pass`, `conf_pass`, `city_name`, `mob_n`, `gender`) VALUES
(1, 'mamata', 'mamata', 'mamata', 'Guwahati', '3673887665', 'Other'),
(2, 'mahuk kumari', 'mahukk', 'mahukk', 'Modoroi', '3973887665', 'Other'),
(3, 'Nmika  Rani', 'Nmika@', 'Nmika@', 'Hydrabad', '3989388765', 'Female'),
(4, ' Rani charterji', 'charterji', 'charterji', 'Kolkata', '3989388765', 'Female'),
(5, 'Charterji mukherji', 'mukherji', 'mukherji', 'Itanagar', '6789388765', 'Male'),
(6, 'Muna singh', 'muna!@#', 'muna!@#', 'Bokaro', '6789388765', 'Male'),
(7, 'Reya rani', 'Reya098', 'Reya098', 'Kolkata', '6780388765', 'Other'),
(8, 'mata kumari paswan', 'paswan', 'paswan', 'Pune', '6780388765', 'Female'),
(9, 'Dineshwar paswan', 'dineshwar', 'dineshwar', 'Mumbai', '6780388765', 'Female'),
(10, 'Reya sandil', 'sandil', 'sandil', 'Secondrabad', '6780388765', 'Female'),
(11, 'Sunidhi kumari', 'Sunidhi ', 'Sunidhi ', 'Jipur', '6796388765', 'Other'),
(12, 'dinepak yadav', 'dinepak', 'dinepak', 'Lakhnou', '5656564779', 'Male'),
(13, 'khati saram', 'khayati', 'khayati', 'Bhopal', '3467876968', 'Other'),
(14, 'uday paswan', 'uday@12', 'uday@12', 'Secondrabad', '3476877656', 'Other'),
(15, 'Neha  paswan', 'NEHA!23', 'NEHA!23', 'Kolkata', '8476877656', 'Female');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
