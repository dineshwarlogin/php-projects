<?php
try{ 
    $con =new PDO("mysql:host=localhost;dbname=mini_project","root","");
}catch(PDOExection $e){
	echo $e->getMessage();
}	
$sql="SELECT gender,count(gender) as tcount FROM `data` GROUP BY gender";
$stmt=$con->prepare($sql);
$stmt->execute();
$arr=$stmt->fetchAll(PDO::FETCH_ASSOC);
 		
 ?>
<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
            ['Genders', 'Tcounts'],
		<?php foreach($arr as $key=>$val){?>
			['<?php echo $val["gender"]?>', <?php echo $val["tcount"]?>],
		   
		<?php }?> 
			
        ]);

        var options = {
          title: 'Gender Counts',
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <div id="piechart_3d" style="width: 900px; height: 500px;"></div>
  </body>
</html>