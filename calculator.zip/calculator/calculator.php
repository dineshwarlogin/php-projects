
<!DOCTYPE HTML>  
<html>
<head>
<link rel="stylesheet" href="css/style.css"/>
<script type="text/javascript" src="js/script.js"></script><title>Calculator</title>
</head>
<body>  

<h2> Smart Calculator in PHP! </h2>

<form align="center" method="post" action="calculator.php">  
  First value: <input type="int" name="fnum" placeholder="First Value">
  <br><br>
  Oprators:<select  name="opp">
     <option value=""> Select Oprator</option>
	        <option value="Addition">Addition</option>
		    <option value="Multiplication">Multiplication</option>
			<option value="Division">Division</option>
			<option value="Subtraction">Subtraction</option>
			 
  </select>
  <br><br>
  Second value: <input type="int" name="snum" placeholder="Second Value">

  <br><br>
  <input type="submit" name="total" value="TOTAL" id="sub"> 
</form>
  
</body>
</html>
<?php
	function value(){   
		if(isset($_POST["total"])){
			 $num1=$_POST["fnum"]; 
			 $num2 =$_POST["snum"];
			 
			switch($_POST["opp"]){
			 
				case "Addition":
						$sum=$num1 + $num2;
						return $sum;
				break;
				
				case "Multiplication":
						$prod=$num1 * $num2;
						return $prod;
				break;
				case "Division":
						$quo=$num1 / $num2;
						return $quo;
				break;
				case "Subtraction":
						$diff=$num1 - $num2;
						return $diff;
				break;
				default:
					echo "Invalid oppraton!";

			}
		
		}
	}
   echo " This is Total: ".value();
?>