<?php
include("sq_connection.php");
	   
    if(isset($_GET["upd"])){
	    $upd =$_GET["upd"];
		
		$sql_query="SELECT * FROM `person` WHERE per_id='$upd'";
		$data=mysqli_query($con, $sql_query);
		$row=mysqli_fetch_array($data);	
		$lan=$row['language'];
		$lag=explode(",",$lan);
	}
?>
<!DOCTYPE HTML>  
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Update of Seach with Multiple delete!</title>
  <link rel="stylesheet" type="text/css" href="edit_css/style.css"/>

</head>
<body>  
<h2>Multiple Data Update With Checkbox! and Radio Button</h2>

<form align="center" method="post" action="">  
  Name:<input type="text" name="uname" value="<?php  echo $row["uname"]; ?>">
  <br><br>
  E-mail:<input type="text" name="eml" value="<?php  echo $row["eml"]; ?>">
  <br><br>
  City name:<select  name="city">
	 <option value="Delhi" <?php if($row["city"]=='Delhi') {echo "selected"; }?> >Delhi</option>
	 	 <option value="Kolkata" <?php if($row["city"]=='Kolkata') {echo "selected"; }?> >Kolkata</option>
		 	 <option value="Ranchi" <?php if($row["city"]=='Ranchi') {echo "selected"; }?> >Ranchi</option>
			 	 <option value="Mumbai" <?php if($row["city"]=='Mumbai') {echo "selected"; }?> >Mumbai</option>
				 <option value="Hydrabad" <?php if($row["city"]=='Hydrabad') {echo "selected"; }?> >Hydrabad</option>
             <option value="Bangolor" <?php if($row["city"]=='Bangolor') {echo "selected"; }?> >Bangolor</option>
         <option value="Chenai" <?php if($row["city"]=='Chenai') {echo "selected"; }?> >Chenai</option>
    <option value="Patna" <?php if($row["city"]=='Patna') {echo "selected"; }?> >Patna</option>		 
  </select>
  <br><br>
  Comment:<textarea type="text" name="mess" rows="5" cols="40" ><?php echo $row["mess"]?></textarea>
  <br><br>
  Gender:
  <input type="radio" name="gender" value="Female" <?php if($row["gender"]=="Female"){ echo "checked"; }?> >Female
  <input type="radio" name="gender" value="Male" <?php if($row["gender"]=="Male"){ echo "checked"; } ?> >Male
  <input type="radio" name="gender" value="Other" <?php if($row["gender"]=="Other"){ echo "checked"; } ?> >Other  
  <br><br>
  <p style="color:red;">Select Lang Now Below:</p>
  <input type="checkbox" name="language[]" value="English" <?php if(in_array("English",$lag)){ echo "checked";}?>>English
  <input type="checkbox" name="language[]" value="Hindi" <?php if(in_array("Hindi",$lag)){ echo "checked";}?>>Hindi
  <input type="checkbox" name="language[]" value="Bangala" <?php if(in_array("Bangala",$lag)){ echo "checked";}?>>Bangala
  <input type="checkbox" name="language[]" value="Telgue" <?php if(in_array("Telgue",$lag)){ echo "checked";}?>>Telgue   
  <input type="checkbox" name="language[]" value="Punjabi" <?php if(in_array("Punjabi",$lag)){ echo "checked";}?>>Punjabi
  <input type="checkbox" name="language[]" value="Marathi" <?php if(in_array("Marathi",$lag)){echo "checked";}?>>Marathi
  <input type="checkbox" name="language[]" value="Kunude" <?php if(in_array("Kunude",$lag)){ echo "checked";}?>>Kunude  
  <br><br>
  <input type="submit" name="udtade" value="Udtade" id="sub"> 
</form>
</body>
</html>
<?php
	 
    if(isset($_POST["udtade"])){	
	    $uname =$_POST["uname"];
		$eml =$_POST["eml"];
		$city =$_POST["city"];
		$mess =$_POST["mess"];
		$gender =$_POST["gender"];
		$lang =$_POST["language"];
        $language=implode(",",$lang);
		
        $query="UPDATE  person SET uname='$uname', eml='$eml',city ='$city',mess='$mess',gender='$gender',language='$language' WHERE per_id='$upd'";	 
	    $update=mysqli_query($con, $query);
	    if($update){ 
		    echo "<script>alert('Data has been Updated!')</script>";
			echo "<script>window.open('index.php','_self')</script>";
		}
		else{
			"<script>alert('Update has failed');</script>";
		}
		 
	}
     //else{echo "<script>alert('Not Update Data');</script>";}	
		
?>