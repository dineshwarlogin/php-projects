-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 13, 2020 at 12:58 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shopping`
--

-- --------------------------------------------------------

--
-- Table structure for table `del`
--

CREATE TABLE `del` (
  `de_id` int(11) NOT NULL,
  `use_name` varchar(25) NOT NULL,
  `mob` varchar(10) NOT NULL,
  `eml` varchar(30) NOT NULL,
  `city` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `del`
--

INSERT INTO `del` (`de_id`, `use_name`, `mob`, `eml`, `city`) VALUES
(57, 'manoj', '7770096548', 'manopaswan@gmail.com', 'Tata'),
(48, 'khubu shaneha', '2865090086', 'khushbu@gmail.com', 'arah'),
(45, 'mohit paswan', '0987605896', 'mohit@gmail.com', 'begusaroy'),
(46, 'pandeji', '8025835505', 'pande@gmail.com', 'tata'),
(47, 'manisha sekh', '9458043405', 'manish34@gmail.com', 'devghar'),
(58, 'rabi kumar', '8686894099', 'rabi@3445gmail.com', 'kolkata'),
(49, 'sarita agrwal', '6748286484', 'sarita@gmail.com', 'hajaribag'),
(50, 'bara paswan', '0937605676', 'bara@gmail.com', 'begusaroy'),
(59, 'sunjit kumar ', '9875550454', 'sunji.kumar@gmail.com', 'Patna'),
(56, 'sapna kumari', '4805604408', 'sapna@gmail.com', 'munger'),
(62, 'rabi sarma', '8709405637', 'rabi.sarma@gmail.com', 'ranchi'),
(63, 'manoj', '9965356443', 'mano@123gmail.com', 'patna'),
(64, 'daineshwar paswan', '8025835505', 'din@gmial.com', 'tata'),
(65, 'arun paswan', '945783279', 'arun@gmailc.om', 'ranchi'),
(66, 'dineshwar kushwaha', '8735620876', 'rahul@gmail.com', 'hydrabad');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `del`
--
ALTER TABLE `del`
  ADD PRIMARY KEY (`de_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `del`
--
ALTER TABLE `del`
  MODIFY `de_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
