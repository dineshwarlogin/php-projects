<?php
	 
include("sq_connection.php");
      
    if(isset($_POST["submit"])){
	    $uname =$_POST["uname"];	  
		$eml =$_POST["eml"];
		$city =$_POST["city"];
	    $mess =$_POST["mess"];
		$gen =$_POST["gender"];
		$gender=implode(" ",$gen);
		$lan =$_POST["language"];
        $language=implode(",",$lan);
		$query="INSERT INTO `person`(`uname`, `eml`, `city`, `mess`, `gender`, `language`) VALUES ('$uname','$eml','$city','$mess','$gender','$language')";
		
		$result=mysqli_query($con, $query);
		if($result){
		         echo "<script>alert('Data has been Submited')</script>";
				 echo "<script>window.open('index.php','_self')</script>";

		}
		else{
		    echo "<script>alert('Data has Not Submited')</script>";
		     
	    }
	}	
?>
<!DOCTYPE HTML>  
<html>
<head>
<title>Form use radio And checkbox</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1"> 
<link rel="stylesheet" type="text/css" href="add_css/style.css"/>
</head>
<body>  
<h2> Insert here data!</h2>

<form align="center" method="post" action="add.php">  
  Name: <input type="text" name="uname" placeholder="Only Name" autocomplete="off" required>
  <br><br>
  E-mail: <input type="text" name="eml" placeholder="Only Email" autocomplete="off" required>
  <br><br>
  <!-----Dropdown start--->
    
    City name:<select  name="city" required>
     <option value=""> Select any city</option>
	 <option value="Delhi"> Delhi</option>
	 	 <option value="Kolkata"> Kolkata</option>
		 	 <option value="Ranchi"> Ranchi</option>
			 	 <option value="Mumbai"> Mumbai</option>
				<option value="Hydrabd"> Hydrabad</option>
             <option value="Bangolor"> Bangolor</option>
         <option value="Chenai"> Chenai</option>
       <option value="Patna">Patna</option>		 
    </select>
  <!-----Dropdown End/--->
  <br><br>
  Comment:<textarea name="mess" rows="5" cols="40"  placeholder="please type some texte here..............."required></textarea>
  <br><br>
  <!-----Radio button start--->
  <b style="color:yellow;">Gender Below:</b><br> 
    <?php 
     $gend=array('Female','Male','Other');
	 foreach($gend as $value){
		 
    ?>
    <?php echo $value;?><input type="radio" name="gender[]" value="<?php echo $value;?>" required>
   <?php }?>
   <!-----Radio button End/--->  
  <br><br>
  <!-----Checkbox start--->
  <b style="color:orange;">Select Language Below:</b><br>
    <?php 
	    $langu=array('English','Hindi','Bangala','Telgue','Punjabi','Marathi','Kunude');
	    foreach($langu as $list){
			
		?>		
      <?php echo $list;?><input type="checkbox" name="language[]" value="<?php echo $list;?>">
    <?php } ?>
	<!-----Checkbox End/--->
  <br><br>
  <input type="submit" name="submit" value="Submit" id="id"> 
</form>
</body>
</html>
