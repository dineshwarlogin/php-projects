-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 07, 2020 at 07:33 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mini_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

DROP TABLE IF EXISTS `person`;
CREATE TABLE IF NOT EXISTS `person` (
  `per_id` int(111) NOT NULL AUTO_INCREMENT,
  `uname` varchar(30) NOT NULL,
  `eml` varchar(50) NOT NULL,
  `city` varchar(30) NOT NULL,
  `mess` varchar(100) NOT NULL,
  `gender` text NOT NULL,
  `language` varchar(150) NOT NULL,
  PRIMARY KEY (`per_id`)
) ENGINE=MyISAM AUTO_INCREMENT=55 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `person`
--

INSERT INTO `person` (`per_id`, `uname`, `eml`, `city`, `mess`, `gender`, `language`) VALUES
(1, 'dineshwar paswan', 'dineshwar@gmail.com', 'Patna', 'i am engg in cotocus', 'Male', 'Hindi,English,'),
(2, 'manu paswan', 'manu@gmail.com', 'Ranchi', 'i am bilder', 'Male', 'Hindi,'),
(3, 'papau shaw', 'papau@gmail.com', 'Ranchi', 'i am farmer', 'Male', 'English,'),
(4, 'mira sharam', 'mira@gmail.com', 'Patna', 'i am contractor', 'Male', 'Hindi,Marathi'),
(5, 'sapna baram', 'sapna@gmail.com', 'Kolkata', 'i am techear', 'Female', 'Hindi,Bangala'),
(6, 'mhes kumar', 'mhesh@gmail.com', 'Chenai', 'i am doctor', 'Male', 'English,Telgue,Kunude'),
(7, 'supiriya singh', 'supriya@gmail.com', 'Mumbai', 'i am ips officer', 'Other', 'English,Marathi'),
(8, 'Neha kumari sawant', 'naha@gmail.com', 'Hydrabad', 'i am lidaer of bjp', 'Other', 'Telgue'),
(9, 'divya yadaw ganguli', 'divya@gmil.com', 'Kolkata', 'i am crickter', 'Other', 'Hindi,Bangala'),
(10, 'sonachi sinha', 'sonchi@gmail.com', 'Bangolor', 'i am actres', 'Female', 'English,Hindi,Kunude'),
(11, 'golo mahto', 'golu@gmail.com', 'Patna', 'i am childe', 'Male', 'Hindi'),
(12, 'krish kumar', 'krish@gmail.com', 'Delhi', 'i am student', 'Male', 'English'),
(13, 'Sara ali khan', 'riya@gmail.com', 'Mumbai', 'i am jurnlist', 'Female', 'English,Hindi,Marathi'),
(14, 'anku kumari sinha', 'anu@gmail.com', 'Mumbai', 'i am asstent si', 'Female', 'Hindi,Marathi'),
(15, 'rinki kumari', 'rinki@gmail.com', 'Hydrabad', 'i am police officer', 'Other', 'Hindi,Telgue'),
(16, 'suman kumari', 'suman@gmail.com', 'Chenai', 'i am Siwile Servernt', 'Female', 'English,Telgue'),
(17, 'Sapana kumari ', 'sapana@gmail.com', 'Kolkata', 'i am clerck in sbi', 'Other', 'English,Hindi'),
(18, 'Sonali vender Sinha', 'sonali@gmail.com', 'Bangolor', 'i am mbbs doctors ', 'Other', 'English,Hindi,Kunude'),
(24, 'saradha sinha', 'sardha@gmail.com', 'Ranchi', 'iam officer', 'Female', 'English,Hindi'),
(25, 'Rajesh kumar pandit', 'raje@gmail.com', 'Chenai', 'i am engg', 'Male', 'English,Hindi'),
(26, 'namika sing', 'namika@gmail.com', 'Delhi', 'i am manager', 'Male', 'English,Hindi'),
(27, 'Rani kumari ganguli', 'rani@gbmail.com', 'Kolkata', 'i am major', 'Female', 'Bangala'),
(28, 'Rani kumari ganguli', 'rani@gbmail.com', 'Kolkata', 'i am major', 'Female', 'Hindi,Bangala'),
(29, 'muna sharam', 'muna@gmail.com', 'Mumbai', 'i am bussinemane', 'Male', 'Hindi,Marathi'),
(30, 'chanchan pande', 'pande@gmail.com', 'Chenai', 'i am ', 'Male', 'Bangala,Telgue'),
(31, 'mamat sekhawt', 'mamat@gmail.com', 'Bangolor', 'i am', 'Other', 'Hindi,Telgue'),
(32, 'Rohit paswan', 'rohit@gmail.com', 'Patna', 'i am student', 'Male', 'English,Hindi,Bangala'),
(33, 'palvi kumari', 'palvi@gmail.com', 'Hydrabd', 'i am actores', 'Female', 'English,Telgue'),
(34, 'banda kumari', 'band@gmail.com', 'Kolkata', 'i am ancor', 'Female', 'Hindi,Bangala'),
(35, 'Punam pande', 'punam@gmail.com', 'Chenai', 'I am pundit', 'Female', 'Bangala,Kunude'),
(36, 'Sony aarayan', 'soani@gmail.com', 'Mumbai', 'i am acotor', 'Female', 'English,Telgue,Punjabi'),
(37, 'Aanu thaper', 'aanu@gmail.com', 'Patna', 'i am farmer', 'Female', 'English,Telgue'),
(43, 'Tina sharam', 'tina@gmail.com', 'Patna', 'i am profesher', 'Male', 'English,Hindi'),
(41, 'Richa Sahegale', 'richa@gmail.com', 'Ranchi', 'I am social worker', 'Other', 'English,Telgue'),
(42, 'divya kohli', 'divya@gmail.com', 'Kolkata', 'i am wallfer deparment', 'Male', 'English,Hindi'),
(44, 'sabita patra', 'patar@gmail.com', 'Ranchi', 'i am leder of bjp', 'Other', 'Hindi,Punjabi'),
(45, 'Bindu lakara', 'bundu@gmail.com', 'Kolkata', 'i am ckock', 'Female', 'Telgue'),
(46, 'suntosh prasad', 'suntosh@gmail.com', 'Bangolor', 'i am pilot', 'Male', 'Telgue,Kunude'),
(47, 'depali varama', 'depali@gmail.com', 'Chenai', 'i am cricketer', 'Other', 'Hindi,Telgue'),
(48, 'suma kundra', 'susma@gmail.com', 'Chenai', 'I am indian army', 'Other', 'English,Hindi,Telgue'),
(49, 'kajal raghwani', 'kaja@gmail.com', 'Bangolor', 'i am bhojpuri actor', 'Female', 'Hindi'),
(50, 'sneha baram', 'sneha@gmai.com', 'Hydrabad', 'i am dancer', 'Female', 'Hindi,Telgue'),
(51, 'Raman manji', 'ram@gmail.com', 'Mumbai', 'i am farmer', 'Male', 'Hindi,Marathi'),
(52, 'Manisha kurala', 'manish@gmail.com', 'Ranchi', 'i am dancer', 'Female', 'English,Hindi'),
(53, 'Puja mahi', 'mahi@gmail.com', 'Hydrabad', 'i am army officer', 'Female', 'Hindi');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
