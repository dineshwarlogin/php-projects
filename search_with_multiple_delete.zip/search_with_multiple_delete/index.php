<!DOCTYPE html>
<html lang="en">
<head>
  <title>Seach and Multiple delete</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1"> 
   <style>
  table{background-color:SlateBlue; border-style:solid; border-width:7px; text-align:center; margin-left:300px;}
  th {
  background-color:#ff6347; border-width:5px; text-align:center; border-width:5px; padding:10px;text-color:white;
}
td{
  background-color:#4CAF; border-style:solid; border-width:5px; text-align:center;padding:text-color:white;
}
input{height:28px; border: 2px solid SlateBlue ; border-radius: 5px; text-align:center;}
h2{text-align:center; color:SlateBlue; font-size:25px;}
  </style>
  </head>
<body><h2>Seaching And Deleting Record!</h2>
	<form method="post" action="index.php">
	    <table col="3">
		 <tr>
			<th>Id</th>
			<th>Name</th>
			<th>Mobile</th>
			<th>Email</th>
			<th>City</th>
			<th><input type="submit" name="Delt" value="Delete" onclick="return confirm('Are you sure to Delete')"/></th>
			<th><form method="post" action="search_del.php">  
			<input type="text" name="srch" placeholder="Find Name or city">
			<input type="submit" name="sch" value="Search">  
			</form></th>
		 </tr>
	  
     
	  <?php
		include("sq_connection.php");
	        if(isset($_REQUEST['sch'])){
				$srch=$_REQUEST['srch'];
			$sql="SELECT * FROM del WHERE city like '%".$srch."%' OR use_name like'%".$srch."%'";	
			$count=mysqli_query($con,$sql);
			
			} 
		    else{
				if(isset($_REQUEST['Delt'])){ 
                    @$check =$_REQUEST['check'];
				    @$chk =implode(",",$check);
			      
			$query= "DELETE FROM `del` WHERE de_id in($chk)";
			mysqli_query($con,$query);
			}    			
			$sql="SELECT * FROM del ORDER BY de_id DESC";	
			$count=mysqli_query($con,$sql);
			}
		?>
		<?php			
				while($row = mysqli_fetch_array($count)){
									
		?>    
		  <tr>
			<td><?php echo $row['de_id'];?></td>
			<td><?php echo $row['use_name'];?></td>
			<td><?php echo $row['mob'];?></td>
			<td><?php echo $row['eml'];?></td>
			<td><?php echo $row['city'];?></td>
			<td><input type="checkbox" name="check[]" value="<?php echo $row['de_id'];?>"/></td>
		  </tr>
				<?php }?>
	   
	  </table>
	</form>
  </body>
</html>