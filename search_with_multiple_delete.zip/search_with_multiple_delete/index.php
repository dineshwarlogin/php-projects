<!DOCTYPE html>
<html lang="en">
<head>
  <title>Seach with Multiple delete!</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1"> 
  <link rel="stylesheet" href="style.css"/>
  </head>
<body><h2>Seaching And Deleting with checkbox Record!</h2>
	<form method="post" action="index.php">
	    <table col="3">
		<tr>
            <th>Id</th>
			<th>Name</th>
			<th>Email</th>
			<th>Gender</th>
			<th>Message</th>
			<th>City</th>
			<th>Language</th>
			<th><input type="submit" name="Delt" value="Delete" onclick="return confirm('Are you sure to Delete')"/></th>
			<th>Edit</th>
			<th><form method="post" action="search_del.php">  
			<input type="text" name="srch" placeholder="Find Name or city">
			<input type="submit" name="sch" value="Search">  
			</form></th>
			<th><a href="add.php">Add data</a></th>
		 </tr>
	    <?php
		   include("sq_connection.php");
		   
	        if(isset($_REQUEST['sch'])){
				$srch=$_REQUEST['srch'];
			$sql="SELECT * FROM person WHERE city like '%".$srch."%' OR uname like'%".$srch."%' OR language like'%".$srch."%' OR gender like '%".$srch."%'";	
			$count=mysqli_query($con,$sql);
			
			} 
		    else{
				if(isset($_REQUEST['Delt'])){ 
                    @$check =$_REQUEST['check'];
				    @$chk =implode(",",$check);
			      
				   $query= "DELETE FROM `person` WHERE per_id in($chk)";
				   mysqli_query($con,$query);
				}    			
			   $sql="SELECT * FROM person ORDER BY per_id DESC";	
			   $count=mysqli_query($con,$sql);
			}
		?>
		<?php			
			while($row = mysqli_fetch_array($count)){
									
		?>    
		  <tr>
			<td><?php echo $row['per_id'];?></td>
			<td><?php echo $row['uname'];?></td>
			<td><?php echo $row['eml'];?></td>
			<td><?php echo $row['gender'];?></td>
			<td><?php echo $row['mess'];?></td>
			<td><?php echo $row['city'];?></td>
			<td><?php echo $row['language'];?></td>
			<td><input type="checkbox" name="check[]" value="<?php echo $row['per_id'];?>"/></td>
			<td><a href="edit.php?upd=<?php echo $row['per_id'];?>">Edit</td>
		  </tr>
		<?php }?>
	   
	  </table>
	</form>
  </body>
</html>