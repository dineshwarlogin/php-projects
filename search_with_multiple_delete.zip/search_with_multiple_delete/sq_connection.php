<?php
        // Create connection------------>
		//mysqli_connect("host_name","user_name","password_name","database_name");
	           	//	OR
		//mysqli_connect("localhost","cotocus","","mini_project");
		      // OR
		/*$con = mysqli_connect("localhost","cotocus","","mini_project");
		
			//Check connection
			if(!isset($con)){
				echo "Conn Failed";  
			}
		*/	 
		     // OR
		$con = mysqli_connect("localhost","root","");
	    $result=mysqli_select_db($con,"mini_project");
		//Check connection
		if(!isset($result)){
		    echo "Conn Failed";  
		}
       
?>