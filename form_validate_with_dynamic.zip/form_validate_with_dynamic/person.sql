-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 16, 2020 at 07:39 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mini_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

CREATE TABLE `person` (
  `per_id` int(111) NOT NULL,
  `uname` varchar(30) NOT NULL,
  `eml` varchar(50) NOT NULL,
  `city` varchar(30) NOT NULL,
  `mess` varchar(100) NOT NULL,
  `gender` text NOT NULL,
  `language` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `person`
--

INSERT INTO `person` (`per_id`, `uname`, `eml`, `city`, `mess`, `gender`, `language`) VALUES
(1, 'dineshwar paswan', 'dineshwar@gmail.com', 'Patna', 'i am engg in cotocus', 'Male', 'Hindi,English,'),
(2, 'manu paswan', 'manu@gmail.com', 'Ranchi', 'i am bilder', 'Male', 'Hindi,'),
(3, 'papau shaw', 'papau@gmail.com', 'Ranchi', 'i am farmer', 'Male', 'English,'),
(4, 'mira sharam', 'mira@gmail.com', 'Patna', 'i am contractor', 'Male', 'Hindi,Marathi'),
(5, 'sapna baram', 'sapna@gmail.com', 'Kolkata', 'i am techear', 'Female', 'Hindi,Bangala'),
(6, 'mhes kumar', 'mhesh@gmail.com', 'Chenai', 'i am doctor', 'Male', 'English,Telgue,Kunude'),
(7, 'supiriya singh', 'supriya@gmail.com', 'Mumbai', 'i am ips officer', 'Other', 'English,Marathi'),
(8, 'neha kumari', 'naha@gmail.com', 'Hydrabd', 'i am manager', 'Other', 'English,Telgue'),
(9, 'divya yadaw', 'divya@gmil.com', 'Kolkata', 'i am ancor', 'Other', 'Hindi,Bangala'),
(10, 'sonachi sinha', 'sonchi@gmail.com', 'Bangolor', 'i am actres', 'Female', 'English,Hindi,Kunude'),
(11, 'golo mahto', 'golu@gmail.com', 'Patna', 'i am childe', 'Male', 'Hindi'),
(12, 'krish kumar', 'krish@gmail.com', 'Delhi', 'i am student', 'Male', 'English'),
(13, 'riya khan', 'riya@gmail.com', 'Kolkata', 'i am jurnlist', 'Female', 'English,Hindi,Bangala'),
(14, 'anku kumari', 'anu@gmail.com', 'Hydrabd', 'i am tv actres', 'Female', 'Telgue'),
(15, 'rinki kumari', 'rinki@gmail.com', 'Hydrabd', 'i am actres', 'Other', 'English,Hindi,Kunude'),
(16, 'suman kumari paswan', 'suman@gmail.com', 'Hydrabd', 'i am coler', 'Female', 'English,Telgue,Kunude'),
(17, 'sapana kumari mahto', 'sapana@gmail.com', 'Kolkata', 'i am bca std', 'Other', 'Hindi,Bangala'),
(18, 'sonali vender', 'sonali@gmail.com', 'Bangolor', 'i am tv ancor', 'Female', 'English,Punjabi,Kunude'),
(19, 'tabark khan', 'tabark@gmail.com', 'Delhi', 'i am software eng', 'Male', 'English,Hindi'),
(20, 'alock paswan', 'alock@gmail.com', 'Ranchi', 'i am requeter', 'Male', 'Hindi,Punjabi');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `person`
--
ALTER TABLE `person`
  ADD PRIMARY KEY (`per_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `person`
--
ALTER TABLE `person`
  MODIFY `per_id` int(111) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
