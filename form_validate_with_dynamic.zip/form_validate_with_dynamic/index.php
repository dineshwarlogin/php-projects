<?php
error_reporting(0); 
include("sq_connection.php");
    $u_name="";
    $eml="";
    if(isset($_POST["submit"])){
	
	    $u_name =$_POST["uname"];
		$eml =$_POST["eml"];
		$city =$_POST["city"];
		$mess =$_POST["mess"];
		
		$gen =$_POST["gender"];
		$gender=implode("",$gen);
		$gender_check=0;
		$gender_check = ($gen);
		
		$dep =$_POST["language"];
		$language=implode(",",$dep);
		$check_dep = 0;
		$check_dep = ($dep);
		
		if(empty($u_name)){
			$err_user="Please fill in the required!";
		}
		elseif((strlen($u_name)<=2) OR (strlen($u_name)>=26)){
			$err_corect="Minimum 3 chrecter and Maxi 25 allowed!";
		}
		elseif(!preg_match('/^[a-zA-Z ]*$/', $u_name)){
			$err_str="Not allowed Special chrecter and Int!";
		} 
		
		elseif(empty($eml)){
			$err_eml="Please fill in the required!";
		}
		elseif(!filter_var($eml, FILTER_VALIDATE_EMAIL)){
			$err_mail="Please valid email address!";
		}
		
		elseif(!$city){
			$err_cit="Select at lest One City!";	
		}
		elseif(!$mess){
			$err_mess="Something write Anything content!";	
		}
		elseif($gender_check<1){
			$err_gen="Select at lest one Gender!";	
		}
		elseif($check_dep<1){
			$err_dep="Please at lest one Deparment!";
		}
		else{
		    	
			$query="INSERT INTO person(uname, eml, city, mess, gender, language) VALUES ('$u_name','$eml','$city','$mess','$gender','$language')";
			mysqli_query($con, $query);
			echo "<script>alert('Data has submited')</script>";
		}
	}
	else{
		echo "<script>alert('Not submited')</script>";
	}
?>
<!DOCTYPE HTML>  
<html>
<head>
<title>form validate with Dynamic </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1"> 
<link rel="stylesheet" href="css/style.css"/>
</head>
<body>  
<h2>Multiples Data Insert With Validate Dynamic</h2>

<form align="center" method="post" action=""> 
  <label>Name: <input type="textbox" name="uname" placeholder="User Name" autocomplete="off" value="<?php echo $u_name;?>"/>
     &nbsp;&nbsp;<span id="error">
				 <?php 
				if(isset($err_user)){
					echo $err_user;
				} 
				elseif(isset($err_corect)){ 
				     echo $err_corect;
				}
				elseif(isset($err_str)){ 
				       echo $err_str;
				}
				 ?>
				</span>
  </label>
  <br><br>
  <label>E-mail: <input type="textbox" name="eml" placeholder="Only Email" autocomplete="off" value="<?php echo $eml;?>"/>
    &nbsp;&nbsp;<span id="error">
					<?php 
						if(isset($err_eml)){ 
							echo $err_eml;
						} 
						elseif(isset($err_mail)){
							echo $err_mail;
						}
					?>
				</span>
  </label>
  <br><br>
  <label>
	  City :<select  name="city">
		 <option value=""> Select any city</option>
		 <option value="Delhi"> Delhi</option>
			 <option value="Kolkata"> Kolkata</option>
				 <option value="Ranchi"> Ranchi</option>
					 <option value="Mumbai"> Mumbai</option>
					<option value="Hydrabd"> Hydrabad</option>
				 <option value="Bangolor"> Bangolor</option>
			 <option value="Chenai"> Chenai</option>
		<option value="Patna">Patna</option>		 
	  </select>
	  &nbsp;&nbsp;<span id="error"><?php if(isset($err_cit)){ echo $err_cit;}?></span>
  </label>
  <br><br>
  <label>
  Comment:<textarea name="mess" rows="5" cols="35" placeholder="please type some texte here" value=""><?php echo $mess;?></textarea>
  &nbsp;&nbsp;<span id="error"><?php if(isset($err_mess)){ echo $err_mess;}?></span>
  </label>
  <br><br>
  <label>
	  Gender:
	  <input type="radio" name="gender[]" value="Female">Female
	  <input type="radio" name="gender[]" value="Male">Male
	  <input type="radio" name="gender[]" value="Other">Other 
	  &nbsp;&nbsp;<span id="error"><?php if(isset($err_gen)){ echo $err_gen;}?></span>
  </label>
  <br><br>
  <label>
	  Select Dep:
	  <input type="checkbox" name="language[]" value="Banking">Banking 
	  <input type="checkbox" name="language[]" value="Defence">Defence
	  <input type="checkbox" name="language[]" value="Railway">Railway
	  <input type="checkbox" name="language[]" value="Reasercher">Reasercher
	  &nbsp;&nbsp;<span id="error"><?php if(isset($err_dep)){ echo $err_dep;}?></span>
  </label>  
  <br><br>
  <input type="submit" name="submit" value="Submit" id="sub"> 
</form>
</body>
</html>