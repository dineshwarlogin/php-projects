<?php
   session_start();
   $name  = $_POST['name0'];
   $price= $_POST['price1'];
   $qty = $_POST['qty2'];
   $event = $_POST['event'];
   
   $product = array($name,$price,$qty);
   
    if($event == "Update"){
	   $_SESSION[$name] = $product;
    }
    else if($event == "Delete"){
	   unset($_SESSION[$name]);// Only use particular value for delete session,
	   //session_destroy(); //multiple value for the use delete session 
    }
   header('location:cart_view.php');
   
?>
