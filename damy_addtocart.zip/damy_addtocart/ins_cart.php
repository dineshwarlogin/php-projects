<?php
   session_start();
   
   $name  = $_POST['name'];
   $price= $_POST['price'];
   $qty = $_POST['qty'];
   $product = array($name,$price,$qty);
   $_SESSION[$name] = $product;
   header('location:index.php');
   
?>
