<?php
$con = mysqli_connect("localhost","cotocus");
mysqli_select_db($con,"shopping") or die ("Check connection");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Online Shoppe </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<!---bt 4.4.1--ver---->  
    <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"> 
  <!-- Latest compiled JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<!----4.4.1 bt ver end /---->
  <script src='https://kit.fontawesome.com/a076d05399.js'></script><!-- icon -->
<!---------slider sarat --->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<!---------slider end/--->
</head>
<body>
    <!---nav bar start ---->
	<nav class="navbar navbar-expand-md bg-primary navbar-dark">
	  <a class="navbar-brand " href="index.php"><h3><i class="fas fa-gift text white">&nbsp;&nbsp;Online Shoppe</i></h3></a>
	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
		<span class="navbar-toggler-icon"></span>
	  </button>
	  <form action="search.php" method="post" style="margin-left:300px; background-color:red; border:3px solid orange; border-radius:5px;font-weight:bold;">
			 <input type="text" name="search" placeholder="Product Search"/>
			 <input type="submit" name="submit" class="bg-warning text-white font-weight-bold" value="Search"/>
	  </form>
	  <div class="collapse navbar-collapse" id="collapsibleNavbar" style="margin-left:200px;">
		<ul class="navbar-nav ml-auto">
		  <li class="nav-item">
			<a class="nav-link active text-white" href="index.php"><b>Products</b></a>
		  </li>
		  <li class="nav-item">
			<a class="nav-link text-white" href="checkout.php"><b>Checkout</b></a>
		  </li>
		  <li class="nav-item">
			<a class="nav-link" href="cart_view.php">
			  <i class="fas fa-shopping-cart" style="font-size:30px; color:orange"></i>
			  <span class="badge badge-danger" id="cart-item" style="font-size:18px">0</span>
			</a>
		  </li> 
		</ul>
	  </div>  
	</nav><!----end nav--->
	<div class="container"><!----container banner --->
	  <div id="myCarousel" class="bg-primary carousel slide" data-ride="carousel">
		<!-- Indicators -->
		<ol class="carousel-indicators">
		    <?php
			 
		    $sql_data="Select * From slider_banner";
		    $data=mysqli_query($con,$sql_data);
			$i=1;
		    foreach($data as $data_record){
			        $active ='';
				if($i==1){
					$active ='active';
				}
	        ?>
		    
			<img src="banner/<?php echo $data_record['ban_images']?>" alt="Los Angeles" style="height:30px;" data-target="#myCarousel" data-slide-to="<?php echo $i;?>" class="<?php echo $active;?>">
			<!---<li data-target="#myCarousel" data-slide-to="<?php// echo $i;?>" class="<?php// echo $active;?>"></li><br/>---->
		    <?php $i++;} ?>
		</ol>

		<!-- Wrapper for slides -->
		<div class="carousel-inner">
            <?php
			 
		    $sql_data="Select * From slider_banner";
		    $data=mysqli_query($con,$sql_data);
			$i=1;
		    foreach($data as $data_record){
			        $active ='';
				if($i==1){
					$active ='active';
				}
		    ?>
		    <div class="item <?php echo $active;?>">
			    <img src="banner/<?php echo $data_record['ban_images']?>" alt="Los Angeles" style="height:200px;">
				 <div class="carousel-caption">
			      <h3><?php echo $data_record['banner_name']?>!</h3>
			      <p>&#8377: <?php echo $data_record['ban_price']?></p>
			    </div>
		    </div>
		    <?php $i++;}?>
		</div> <!-- Wrapper for slides end/-->
		<!-- Left and right controls -->
		<a class="left carousel-control" href="#myCarousel" data-slide="prev">
		  <span class="glyphicon glyphicon-chevron-left"></span>
		  <span class="sr-only">Previous</span>
		</a>
		<a class="right carousel-control" href="#myCarousel" data-slide="next">
		  <span class="glyphicon glyphicon-chevron-right"></span>
		  <span class="sr-only">Next</span>
		</a>
	   </div>
    </div> <!---container 1 end for banner/----> 
    <div class="container"><!---container 2 start for products---->
        <div class="row">
            <div class="col">
			   <div class="card">
			        <form action="ins_cart.php" method="post">
			            <h6 class="card-title bg-info text-white p-2 h-100"><b>Apple iphone</b></h6>
					    <div class="cord-body text-danger text-center">
					        <img src="images/Apple_iPhone.jpg" alt="phone" class="w-50 mb-2">
							<h6>&nbsp;&#8377;4800:&nbsp;&nbsp;(<span> 5%</span> off)</h6>
							<h6 class="badge badge-success">4.4<i class="fa fa-star"></i></h6>
							<input type="hidden" name="name" value="Apple iphone11" class="form-control">
							<input type="hidden" name="price" value="4800"class="form-control">
							<input type="text" name="qty" class="form-control" placeholder="Please Type Quintity">
							<button class="btn-success flex-fill w-100"><b>Add to cart</b></button>
						</div>	
                    </form>						
			    </div>
			</div>
			<div class="col-3">
			   <div class="card">
			        <form action="ins_cart.php" method="post">
			            <h6 class="card-title bg-info text-white p-2 h-100"><b>Dell Core9</b></h6>
					    <div class="cord-body text-danger text-center">
					        <img src="images/laptop-php-mac.jpg" alt="phone" class="w-50 mb-2">
							<h6>&nbsp;&#8377;7500:&nbsp;&nbsp;(<span> 10%</span> off)</h6>
							<h6 class="badge badge-success">4.4<i class="fa fa-star"></i></h6>
							<input type="hidden" name="name" value="Dell Core9" class="form-control">
							<input type="hidden" name="price" value="7500"class="form-control">
							<input type="text" name="qty" class="form-control" placeholder="Please Type Quintity">
							<button class="btn-success flex-fill w-100"><b>Add to cart</b></button>
						</div>
					</form>						
			    </div>
			</div>
			<div class="col-3">
			   <div class="card">
			        <form action="ins_cart.php" method="post">
			            <h6 class="card-title bg-info text-white p-2 h-100"><b>Mobile Andoried</b></h6>
					    <div class="cord-body text-danger text-center">
					        <img src="images/mobile-andoried.jpg" alt="mobile" class="w-50 mb-2">
							<h6>&nbsp;&#8377;9000:&nbsp;&nbsp;(<span> 10%</span> off)</h6>
							<h6 class="badge badge-success">4.4<i class="fa fa-star"></i></h6>
							<input type="hidden" name="name" value="Mobile Andoried" class="form-control">
							<input type="hidden" name="price" value="9000"class="form-control">
							<input type="text" name="qty" class="form-control" placeholder="Please Type Quintity">
							<button class="btn-success flex-fill w-100"><b>Add to cart</b></button> 
						</div>
                     </form>						
			    </div>
			</div>
			<div class="col-3">
			   <div class="card">
			        <form action="ins_cart.php" method="post">
			            <h6 class="card-title bg-info text-white p-2 h-100"><b>Bajaja city100</b></h6>
					    <div class="cord-body text-danger text-center">
					        <img src="images/Bajaje_73.jpg" alt="bike" class="w-50 mb-2">
							<h6>&nbsp;&#8377;5800:&nbsp;&nbsp;(<span> 8%</span> off)</h6>
							<h6 class="badge badge-success">4.4<i class="fa fa-star"></i></h6>
							<input type="hidden" name="name" value="Bajaje city100" class="form-control">
							<input type="hidden" name="price" value="5800"class="form-control">
							<input type="text" name="qty" class="form-control" placeholder="Please Type Quintity">
							<button class="btn-success flex-fill w-100"><b>Add to cart</b></button> 
						</div>
                    </form>						
			    </div>
			</div>
            
	    </div>

	</div>
</body>
</html>
