<?php
   session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Cart View/Online shoppe </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  
  <!-- Latest compiled JavaScript -->
  <script src='https://kit.fontawesome.com/a076d05399.js'></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
 
</head>
<body>
	<nav class="navbar navbar-expand-md bg-primary navbar-dark">
	  <a class="navbar-brand" href="index.php"><h3><i class="fas fa-gift text white">&nbsp;&nbsp;Home</i></h3></a>
	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
		<span class="navbar-toggler-icon"></span>
	  </button>
	  <div class="collapse navbar-collapse" id="collapsibleNavbar">
		<ul class="navbar-nav ml-auto">
		  <li class="nav-item">
			<a class="nav-link active text-white" href="index.php"><b>Products</b></a>
		  </li>
		  <li class="nav-item">
			<a class="nav-link text-white" href="index.php"><b>Categories</b></a>
		  </li>
		  <li class="nav-item">
			<a class="nav-link text-white" href="checkout.php"><b>Checkout</b></a>
		  </li>
		  <li class="nav-item">
			<a class="nav-link" href="view_cart.php">
			  <i class="fas fa-shopping-cart" style="font-size:30px; color:orange"></i>
			  <span class="badge badge-danger" id="cart-item" style="font-size:18px">2</span>
			</a>
		  </li> 
		</ul>
	  </div>  
	</nav><br>
   <h2 style="margin-left:500px;"><b>Your Cart Products!</b></h2><br/>
<div class="container">
	<table class="table table-bordered">
		<thead class="btn-dark text-center">
			  <tr>
				<th>Serial n.</th>
				<th>Name</th>
				<th>Price</th>
				<th>Quntity</th>
				<th>Sub Price</th>
				<th>Update</th>
				<th>Delete</th>
			  </tr>
		</thead>
		<tbody class="text-center">
          <?php
		    $bill = 0;
		    $sub_total=0;
		    $srln = 1;
		    foreach($_SESSION as $products){		
			  $p=0;
			  $q=0;			
			    echo "<tr>";
				   echo "<td width='20'><b>".($srln++)."</b></td>";
			       echo "<form action='edit_cart.php' method='post'>";
				    foreach($products as $key => $val){
					    if($key == 2){ 
						   echo "<td width='20'><input type='text' name='qty$key' class='form-control' value='".$val."'></td>";
						    $q = $val;
					    }
					    else if($key == 1){
					        echo "<input type='hidden' name='price$key' value='".$val."'>";
						    echo "<td width='80' class='text-danger'><b>&#8377;".$val."<b></td>";
						   $p = $val;
					    }
					    else if($key == 0){
						   echo "<input type='hidden' name='name$key' value='".$val."'>";
                           echo "<td  width='160' class='text-danger'><b>".$val."</b></td>";							
					    }
					
				    } 
					
				     $bill = $q * $p;
                   echo "<td width='160' class='text-danger text-center'><b>&#8377;".$bill."</b></td>";
                   echo '<td width="20"><input type="submit" name="event" value="Update" class="btn btn-primary"></td>';
				   echo '<td width="20"><input type="submit" name="event" value="Delete" class="btn btn-danger"></td>';
				   echo"</form>";
			    echo "</tr>";
			
			    $sub_total += $bill;
			
		    }
		       echo "<tr>";
			      echo'<td class="text-right" colspan="4"><input type="submit" name="pay" value="Proceed" class="btn btn-warning font-weight-bold"></td>';
		          echo '<td colspan="1"><b>Totale Price: </b><b class="text-danger">&#8377; '.($sub_total).'</b></td>';
			      echo '<td colspan="2"><h4 class="text-white font-weight-bold"><a href="index.php">Continue Shopping</a></h4></td>';
			   echo "</tr>";
	     ?>
		</tbody>   	
	</table>
    </div>     
</body>
</html>