-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 13, 2020 at 12:35 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shopping`
--

-- --------------------------------------------------------

--
-- Table structure for table `checkbox`
--

CREATE TABLE `checkbox` (
  `id` int(11) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `eml` varchar(25) NOT NULL,
  `mss` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `city` varchar(20) NOT NULL,
  `department` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `checkbox`
--

INSERT INTO `checkbox` (`id`, `uname`, `eml`, `mss`, `gender`, `city`, `department`) VALUES
(129, 'ranmu paswan', 'ramu@gmail.com', 'rahu is railway emp', 'Male', 'Mumbai', 'Railway'),
(128, 'nagama sinha', 'nagam@gmail.com', 'nagam is ips officer in kolkata police', 'Female', 'Kolkata', 'Defence'),
(126, 'cotocus', 'cotocus@gmail.com', 'cotocus is software companay', 'Other', 'Bangolor', 'Banking,Defence,Railway,Reasercher'),
(132, 'mnisa kumari', 'manish@gmail.com', 'manisha is best emp', 'Other', 'Bangolor', 'Banking'),
(131, 'mukesh', 'mukesh@gmail.com', 'mukhesh is banking officer', 'Male', 'Delhi', 'Banking'),
(125, 'kunchan', 'kunchan@gmail.com', 'kunchan is bery smart girl', 'Female', 'Ranchi', 'Banking,Defence'),
(174, 'papau', 'papu@gmail.com', 'papau', 'Male', 'Mumbai', 'Defence'),
(166, 'Amar deep', 'amar@gmail.com', 'amardep is manager', 'Male', 'Patna', 'Banking'),
(191, 'dineshwar paswan', 'dinesh@gmail.com', 'i am scientist', 'Male', 'Ranchi', 'Reasercher'),
(222, 'pratap sing', 'prast@gmail.com', 'pratp is defence', 'Male', 'Ranchi', 'Banking,Defence,Railway'),
(198, 'nana bindiya', 'nana@gmail.com', 'nana is manager', 'Female', 'Kolkata', 'Banking'),
(221, 'Sudhir', 'sudh@gmail.com', 'i am section engg', 'Male', 'Kolkata', 'Railway'),
(223, 'rahul guswami', 'rahul@gmail.com', 'hi..i am indian amry ', 'Male', 'Bangolor', 'Defence');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `checkbox`
--
ALTER TABLE `checkbox`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `checkbox`
--
ALTER TABLE `checkbox`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=224;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
