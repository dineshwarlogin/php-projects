
<!DOCTYPE HTML>  
<html>
<head>
<link rel="stylesheet" href="css/style.css"/>
</head>
<body>  

<?php
	 
include("sq_connection.php");
      // $sql="INSERT  INTO checkbox ('uname','eml','mss','gender') VALUES ($uname,$eml,$mss,$gender)";
	   
// define variables and set to empty values

    if(isset($_POST["submit"])){
		 
	    @$id =$_POST["id"];
	    $uname =$_POST["uname"];
		$eml =$_POST["eml"];
		$city =$_POST["city"];
		$mss =$_POST["mss"];
		@$gen =$_POST["gender"];
		@$gender=implode(",",$gen);
		@$dep =$_POST["department"];
        @$department=implode(",",$dep);		
		
		$query="INSERT INTO checkbox(uname, eml, city, mss, gender, department) VALUES ('$uname','$eml','$city','$mss','$gender','$department')";
		mysqli_query($con, $query);
		echo "<script><h3>Data has submited</h3></script>";
	}
    else{
		echo "<script><h3>Data has not submited</h3></script>";
	}
		
?>

<h2>PHP Form|| Single data insert with Checkbox & Radio and Select </h2>

<form align="center" method="post" action="checkbox_radio.php">  
  Name: <input type="text" name="uname" placeholder="Only Name"/>
  <br><br>
  E-mail: <input type="text" name="eml" placeholder="Only Email"/>
  <br><br>
  City name:<select  name="city">
     <option value=""> Select any city</option>
	 <option value="Delhi"> Delhi</option>
	 	 <option value="Kolkata"> Kolkata</option>
		 	 <option value="Ranchi"> Ranchi</option>
			 	 <option value="Mumbai"> Mumbai</option>
				<option value="Hydrabd"> Hydrabad</option>
             <option value="Bangolor"> Bangolor</option>
         <option value="Chenai"> Chenai</option>
    <option value="Patna">Patna</option>		 
  </select>
  <br><br>
  Comment:<textarea name="mss" rows="5" cols="40"  placeholder="please type some texte here..............."></textarea>
  <br><br>
  Gender:
  <input type="radio" name="gender[]" value="Female">Female
  <input type="radio" name="gender[]" value="Male">Male
  <input type="radio" name="gender[]" value="Other">Other 
  <br><br>
  Select Dep:
  <input type="checkbox" name="department[]" value="Banking">Banking 
  <input type="checkbox" name="department[]" value="Defence">Defence
  <input type="checkbox" name="department[]" value="Railway">Railway
  <input type="checkbox" name="department[]" value="Reasercher">Reasercher    
  <br><br>
  <input type="submit" name="submit" value="Submit" id="sub"> 
</form>
</body>
</html>