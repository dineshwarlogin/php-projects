<?php
	session_start();
	if(!isset($_SESSION['uname'])){
		header("location:index.php");
    }
    else{
?>		
<?php
    //connection to database
    $con = mysqli_connect("localhost","cotocus");
	mysqli_select_db($con,"shopping");
	
	//select product id for delete
	$del = $_GET['del'];
	
	//$prod ="DELETE FROM `shoppcart` WHERE id='$del'";
	$prod ="DELETE FROM `shoppcart` WHERE image='$del'";
	$alert=mysqli_query($con,$prod);
	if($alert){
		//echo "<script>alert('Are you sure cancel')</script>";
	         //header('location:delete.php');
        	unlink("images/$del");		 
	}
	header('location:view_page.php');
?>
<?php } ?>