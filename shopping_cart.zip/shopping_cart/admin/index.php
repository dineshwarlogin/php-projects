<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin login Page/Shopping </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>
<div class="jumbotron bg-warning text-center"
	
       <button type="button" class="btn btn-light text-danger"><h1 class="text-light mb-5" style="font-family:'abrial fatface';"><b>ADMIN LOGIN PAGE </b></h1></button>
</div>
<div class="col-sm-5" style="margin-left:400px;">
  <form  method="post" action="index.php" class="needs-validation novalidate">
      <div class="form-group">
      <label for="user">Username:</label>
      <input type="text" class="form-control" id="user" placeholder="Enter username" name="uname" required>
    
    </div>
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="password" required>
      
    </div>
    <div class="form-group form-check">
      <label class="rem">
        <input class="form-check-input" type="checkbox" id="rem" name="rem" required>Remember me.
      </label>
    </div>
    <input type="submit" class="btn btn-primary" name="login" value="Login">
  </form>
</div>
<?php
$con = mysqli_connect("localhost","cotocus");
mysqli_select_db($con,"shopping");
		
	if(isset($_POST['login'])){
	    $user = mysqli_real_escape_string($con,$_POST['uname']);
	    $pswd = mysqli_real_escape_string($con,$_POST['password']);
		$encrypt=md5($pswd);
		
		    $adm = "SELECT * FROM admin  WHERE uname='$user' AND password='$pswd'";
		    $record = mysqli_query($con,$adm);
		    $num = mysqli_num_rows($record);
			if($num>0) {
					$_SESSION['uname'] = $user;
			        header("location:view_page.php");
			}
			else{
               echo "<script>alert('Admin Name or Password is Incorrect!')</script>";
                    header('location:index.php');
	        } 		
	}
?>
</body>
</html>