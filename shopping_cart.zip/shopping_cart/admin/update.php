<?php
	session_start();
	if(!isset($_SESSION['uname'])){
		header("location:index.php");
    }
    else{ 
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Update Product </title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>

    <div class="jumbotron bg-warning text-center">
       <h1 class="text-white mb-5" style="font-family:'abrial fatface';"><b>YOU CAN UPDATE PRODUCTS FOR SELLING  </b></h1>
    </div>

<div class="container col-sm-7">
<?php
		// Create connection
	$con = mysqli_connect("localhost","cotocus");
	mysqli_select_db($con,"shopping");
	// Check connection
	    if($con){
	         echo "";  
	    }
	      /* else{
	          echo "not connected";
	       }*/

		$upd = @$_GET['upd'];
		
        $edit_query = "SELECT `name`, `image`, `price`, `discount`, `p_code` FROM `shoppcart` where id ='$upd'";
		$edit_data = mysqli_query($con,$edit_query);
		while($row = mysqli_fetch_array($edit_data)){
			
			$pro_name = $row['name'];
			$pro_image = $row['image'];
			$pro_price = $row['price'];
			$pro_discount = $row['discount'];
			$pro_code = $row['p_code'];
		}

	if(isset($_POST['update'])){
			$upd_name =$_POST['name'];
			$upd_price =$_POST['price'];
		    $upd_dis =$_POST['discount'];
			$upd_code =$_POST['p_code'];
			
			if(isset($_FILES['image']['name']) && ($_FILES['image']['name']!=" ")){
				
			   $size=$_FILES['image']['size'];
			   $temp=$_FILES['image']['tmp_name'];
			   $type=$_FILES['image']['type'];
			   $profile_name=$_FILES['image']['name'];
				
			   unlink('images/$old_image');   //1st Delete old file from folder
			   move_uploaded_file($temp,'images/$profile_name');    // new image upload to folder
			}
	        else{ 
				echo $profile_name=$old_image;
			}

			$products="UPDATE `shoppcart` SET `id`='$upd',`name`='$upd_name',`image`='$profile_name',`price`='$upd_price',`discount`='$upd_dis',`p_code`='$upd_code' WHERE id='$upd'";
			$update=mysqli_query($con, $products);
			
            if($update){	
				
				echo header('location:view_page.php');
			} 
	
	}
mysqli_close($con);
?>
	
	 <form action="update.php?upd=<?php echo $upd ?>" method="post" enctype="multipart/form-data">
		   <table   align="center" border="2px" style="width:500px; height:50px;background-color:orange;">
			<thead>
			     <tr><th>Product Name</th><td><input type="text" value="<?php echo $pro_name ?>" name="name"></td></tr>
				 <tr><th>Product Rs</th><td><input type="text" value="<?php echo $pro_price ?>" name="price"></td></tr>
				 <tr><th>Discount Rs</th><td><input type="text" value="<?php echo $pro_discount ?>" name="discount"></td></tr>
				 <tr><th>Code</th><td><input type="text" value="<?php echo $pro_code ?>" name="p_code"></td></tr>
				 <tr><th>Image</th><td><img src="images/<?php echo $pro_image ?>" alt="phone" width="100" height="60"><input type="file" name="image" style="background-color: #4cf3;border: 2px solid black"/></td></tr>
				 <tr><th></th><td><input type="submit" value="Update" style="background-color: #4CAF50; border: 1px solid powderblue;color:white;border:2px solid black;font-weight:bold"; name="update" onclick="return confirm('Are you sure for update Products');" ></td></tr>
			</thead>
		</table>
	</form>
        <script>
			// Add the following code if you want the name of the file appear on select
			$(".custom-file-input").on("change", function() {
			  var fileName = $(this).val().split("\\").pop();
			  $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
			});
	    </script>
   </div>
</body>
</html>
	<?php } ?>