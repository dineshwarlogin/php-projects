<?php
	session_start();
	if(!isset($_SESSION['uname'])){
		header("location: index.php");
    }
    else{ 
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Edit Product </title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>

    <div class="jumbotron bg-warning text-center">
       <h1 class="text-white mb-5" style="font-family:'abrial fatface';"><b>YOU CAN EDIT WITH UDATE PRODUCTS FOR SELLING  </b></h1>
    </div>
	
	<?php
		// Create connection
		$con = mysqli_connect("localhost","cotocus");
		mysqli_select_db($con,"shopping");

		$edit = @$_GET['edit'];
        $edit_query = "SELECT `name`, `image`, `price`, `discount` FROM `shoppcart` where id ='$edit'";
		$edit_data = mysqli_query($con,$edit_query);
		while($row = mysqli_fetch_array($edit_data)){
			$edit_name = $row['name'];
			$edit_image = $row['image'];
			$edit_price = $row['price'];
			$edit_discount = $row['discount'];		
		}
	?>
<div class="container col-sm-7">
        <form action="edit.php?edit_form=<?php echo  $edit; ?>" method="post" enctype="multipart/form_data"/>
			<table border="3" bgcolor="gray" width="900" align="center">
			   <tr> 
				  <td colspan="5" bgcolor="red" align="center"><h2>Editing Post</h2></td>
			  </tr>
			  <tr class="form-group"> 
			      <td align="right"><b>Poroduct Name</b></td>
				  <td><input type="text" class="form-control" value="<?php echo $edit_name;?>" name="name"/></td>
			  </tr>
			  <tr class="form-group"> 
				  <td align="right"><b>Poroduct Image</b></td>
				  <td>
					<input type="file" name="image"/><img src="images/<?php echo $edit_image;?>" alt="phone" width="100" height="60"/>
				  </td>
			  </tr>
			  <tr class="form-group"> 
			      <td align="right"><b>Poroduct Price</b></td>
				  <td><input type="text" class="form-control" id="price" value="<?php echo $edit_price;?>" name="price"/></td>
			  </tr>
			  <tr class="form-group"> 
				  <td align="right"><b>Poroduct Discount</b></td>
				  <td><input type="text" class="form-control" id="discount" value="<?php echo $edit_discount;?>" name="discount"/></td>
			  </tr>
			  <tr> 
				  <td  align="center" colspan="5" bgcolor="red"> <input type="submit" class="btn btn-primary" value="update" name="update"/></td>
			 </tr>
		</table>
	</form>
    
        <script>
			// Add the following code if you want the name of the file appear on select
			$(".custom-file-input").on("change", function() {
			  var fileName = $(this).val().split("\\").pop();
			  $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
			});
	    </script>
   </div>
</body>
</html>
<?php

		// Create connection
		$con = mysqli_connect("localhost","cotocus");
		mysqli_select_db($con,"shopping");
			
			// Check connection
		  
			 /* if($con){
				   echo "connection is succussefully";  
				}
			   else{
				  echo "not connected";
			   }*/
		if(isset($_POST['update'])){
				
				$edit_form =$_GET['edit_form'];
				$pro_name =$_POST['name'];
				$pro_image =$_FILES['image']['name'];
				$file_tmp =$_FILES['image']['tmp_name'];
				$pro_price =$_POST['price'];
				$pro_dis =$_POST['discount'];
				//loading images to its folder
					$location='images/'.$pro_image;
					move_uploaded_file($file_tmp,$location);
					$pro_update="UPDATE `shoppcart` SET id ='$edit_form',name='$pro_name',image='$pro_image',price='$pro_price',discount='$pro_dis' WHERE id='$edit_form'";		
						if (mysqli_query($con, $pro_update)) {
							echo header('location:view_page.php');
							} 
						else {
							echo "Error: " .$pro_update . "<br>" . mysqli_error($con);
						}
		}
		mysqli_close($con);
		
?>
	<?php } ?>