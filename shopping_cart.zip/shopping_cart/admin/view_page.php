<?php
session_start();
if(!isset($_SESSION['uname'])){
     header('location:index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>View Page </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="jumbotron bg-warning text-center">
		<button type="button" class="btn btn-light text-danger">
	       <a href="product_form.php" onclick="return confirm('Are you sure for Insert Products');" class=" text-danger"><b>ADD Product</b></a>
	    </button>
		<button type="button" class="btn btn-light text-primary">Welcome<b>:- <?php echo $_SESSION['uname'];?></b></button>
	    <button class="btn btn-light text-danger"><a href="log_out.php" onclick="return confirm('Are you sure logOut');" class="text-danger" role="button"><b>LogOute</b></a></button>
	  
       <h1 class="text-light mb-5" style="font-family:'abrial fatface';"><b>ADMIN PAGE FOR VIEW AND MANAGE PRODUCTS  </b></h1>
    </div>

<div class="container">
		<table class="table table-bordered">
			<thead class="card-title bg-info text-white text-center">
			  <tr>
				<th><h5><b>Product Id</b></h5></th>
				<th><h5><b>Product Name</b></h5></th>
				<th><h5><b>Product Price</b></h5></th>
				<th><h5><b>Discount</b></h5></th>
				<th><h5><b>Images</b></h5></th>
				<th><h5><b>Code</b></h5></th>
				<th colspan="3"><h5><b>Action</b></h5></th>
			  </tr>
			</thead>
			<tbody>
			    <tr>
					<?php
						$con = mysqli_connect("localhost","cotocus");
						mysqli_select_db($con,"shopping");
			  
					   //if($con){
					   //echo "connection is succussefully";  
					   // }
					   // else{
					   //  echo "not connected";
					   // }
			  
						$query = "SELECT `id`, `name`, `image`, `price`, `discount`,`p_code` FROM `shoppcart` order by id DESC";
						$record_query = mysqli_query($con,$query);
						$num = mysqli_num_rows($record_query);
						if($num >0){ 
					      while($product = mysqli_fetch_array($record_query)){
					?>		  
						<td class="card-title bg-warning text-white"><h6><b><?php echo $product['id']; ?></b></h6></td>
						<td class="card-title bg-danger text-white"><h6><b><?php echo $product['name']; ?></b></h6></td>
						<td class="card-title bg-success text-white"><h6><b>&#8377;:<?php echo $product['price']; ?></b></h6></td>
						<td class="card-title bg-info text-white"><h6><b><?php echo $product['discount']; ?> %</span> off)</b></h6></td>
						<td class="bg-secondary"><img src="images/<?php echo $product['image']; ?>" alt="phone" width="50cm" height="20cm" class="img-fluid"></td>
						<td class="card-title bg-info text-white"><h6><b><?php echo $product['p_code']; ?> </b></h6></td>
						<td><button class="btn bg-danger btn"><a href="edit.php?edit=<?php echo $product['id']; ?>" onclick="return confirm('Are you sure for Edit;');" class="text-white"><b>Edit</b></a></button></td>
						<td><button class="btn bg-success btn"><a href="update.php?upd=<?php echo $product['id']; ?>" onclick="return confirm('Are you sure for Update;');"class="text-white"><b>Update</b></a></button></td>
						<td><button class="btn bg-primary btn"><a href="delete.php?del=<?php echo $product['image']; ?>" onclick="return confirm('Are you sure for delete;');" class="text-white"><b>Delete</b></a></button></td>
						
			    </tr>
            <?php }} ?>
			</tbody>
		</table>
   </div>
</body>
</html>