<?php
session_start();
session_destroy(); // unset all session ,session_unset($_SESSION['uname']); particular session destroy
header("location:index.php");
   //echo "<script>window.location.assign(index.php)</script>";
?>
