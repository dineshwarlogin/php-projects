<?php
	session_start();
	if(!isset($_SESSION['uname'])){
		header("location:index.php");
    }
    else{ 
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Insert Product </title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>

    <div class="jumbotron bg-warning text-center">
       <h1 class="text-white mb-5" style="font-family:'abrial fatface';"><b>YOU CAN INSERT PRODUCTS FOR SELLING  </b></h1>
    </div>

<div class="container col-sm-7">
        <?php

		// Create connection
		$con = mysqli_connect("localhost","cotocus");
			mysqli_select_db($con,"shopping");
			
			// Check connection
		  
			 /* if($con){
				   echo "connection is succussefully";  
				}
			   else{
				  echo "not connected";
			   }*/
		if(isset($_POST['submit'])){
				
				$pro_name =$_POST['name'];
				$pro_image =$_FILES['image']['name'];
				$file_tmp =$_FILES['image']['tmp_name'];
				$pro_price =$_POST['price'];
				$pro_dis =$_POST['discount'];
				$pro_code =$_POST['p_code'];
				
				if($pro_name=='' OR $pro_image=='' OR $pro_price=='' OR $pro_dis=='' OR $pro_code==''){
						
					    echo "<script>alert('Please fill all the  field!')</script>";		    
					}
				else{
					//uploading images to its folder
					$location='images/'.$pro_image;
					move_uploaded_file($file_tmp,$location);
				
					$products="INSERT INTO shoppcart(name, image, price, discount, p_code) VALUES ('$pro_name', '$pro_image', '$pro_price', '$pro_dis', '$pro_code')";
		
					if (mysqli_query($con,$products)) {
						 echo header('location:view_page.php');
						} 
				   else {
					   echo "Error: " .$products . "<br>" . mysqli_error($con);
						}
								
				}
		}
	mysqli_close($con);

?>
        <form action="product_form.php" class="col-sm-12" method="post" enctype="multipart/form-data">
			<div class="form-group">
			  <label for="name">Product Name:</label>
			  <input type="text" class="form-control" placeholder="Product name" name="name">
			</div>
			<div class="custom-file">
				<input type="file" class="custom-file-input" id="customFile" name="image">
				<label class="custom-file-label" for="customFile">Choose file</label>
			</div>
			<div class="form-group">
			  <label for="price">Product Price:</label>
			  <input type="text" class="form-control" id="price" placeholder="&#8377 5000" name="price">
			</div>
			<div class="form-group">
			  <label for="discount">Discount Price:</label>
			  <input type="text" class="form-control" id="discount" placeholder="&#8377 50% off" name="discount">
			</div>
			<div class="form-group">
			  <label for="discount">Code:</label>
			  <input type="text" class="form-control" id="p_code" placeholder="p1010" name="p_code">
			</div>
			<input type="submit" class="btn btn-primary" value="Submit" name="submit">
        </form>
        <script>
			// Add the following code if you want the name of the file appear on select
			$(".custom-file-input").on("change", function() {
			  var fileName = $(this).val().split("\\").pop();
			  $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
			});
	    </script>
   </div>
</body>
</html>
<?php } ?>