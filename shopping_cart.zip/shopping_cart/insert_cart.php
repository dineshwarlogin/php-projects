<?php
   session_start();
           
			$name=$_POST["name"];
			$price=$_POST["price"];
			$qty=$_POST["qty"];
		 
    $prd= array($name,$price,$qty);
   $_SESSION[$name] = $prd;
   header('location:index.php');
   
?>
