<?php
   session_start();
   $name  = $_POST['name0'];
   $price= $_POST['price1'];
   $qty = $_POST['qty2'];
   $event = $_POST['event'];
   
   $prd = array($name,$price,$qty);
   
    if($event == "Update"){
	   $_SESSION[$name] = $prd;
    }
    else if($event == "Delete"){
	   unset($_SESSION[$name]);
    }
   header('location:view_cart.php');
   
?>
