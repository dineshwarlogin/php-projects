-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 02, 2020 at 07:23 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shopping`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adm_id` int(10) NOT NULL,
  `uname` varchar(25) NOT NULL,
  `password` varchar(35) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adm_id`, `uname`, `password`) VALUES
(1, 'cotocus', 'cotocus'),
(3, 'dineshwar paswan', 'dineshwar');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(250) NOT NULL,
  `name` varchar(100) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` double NOT NULL,
  `discount` double NOT NULL,
  `qty` int(10) NOT NULL,
  `total_price` double NOT NULL,
  `p_code` varchar(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `clint_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mob_num` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `pmode` varchar(50) NOT NULL,
  `products` varchar(255) NOT NULL,
  `amount_paid` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `shoppcart`
--

CREATE TABLE `shoppcart` (
  `id` int(250) NOT NULL,
  `name` varchar(250) NOT NULL,
  `image` varchar(250) NOT NULL,
  `price` float NOT NULL,
  `discount` float NOT NULL,
  `p_code` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `shoppcart`
--

INSERT INTO `shoppcart` (`id`, `name`, `image`, `price`, `discount`, `p_code`) VALUES
(1, 'Sumsung galexy', 'mobile-andoried.jpg', 8950, 45, 'p001'),
(2, 'Nokia n serise', 'mobile-nokia.jpg', 15500, 25, 'p001'),
(3, 'Sonata ', 'watch-sonata.jpg', 1600, 30, 'p040'),
(4, 'Dell core_i3', 'laptop-php-mac.jpg', 45500, 15, 'p0109'),
(5, 'Karizma 255CC', 'karima.jpg', 160500, 14, 'p2080'),
(6, 'Redmi pro-9', 'redmi_pro_9.jpg', 16500, 18, 'p030'),
(7, 'Nokia Kepaid', 'nokia.jpg', 1850, 16, 'p801'),
(8, 'Sumsung Icore', 'Apple_iPhone.jpg', 34600, 15, 'p010'),
(34, 'Corex Yamaha', '03gd.jpg', 95650, 5, 'p0201'),
(33, 'Farari xgen', '10fdhs.jpg', 3250050, 8, 'p230'),
(66, 'Maruti xzn', 'BMW.gif', 1500800, 15, 'p200'),
(67, 'Maruti suzzuki Alto ', '.XUVI.gif', 980500, 6, 'p90'),
(73, 'Tata Somo', '11.JPG', 1609050, 20, 'p200'),
(74, 'Sentro Xgen 100', 'LOTUS_ELISE_1.JPG', 6700400, 36, 'p0020'),
(87, 'Farari st20', 'Ferrari1.jpg', 105000, 34, 'p0101'),
(88, 'XUV xgen ', 'CAR1A.JPG', 2008000, 23, 'p010'),
(90, 'Pulser 20HK', '8-1.JPG', 152581000, 73, 'p0000'),
(96, 'Suzzuki super bike', 'Brajesh_73.jpg', 2052580000, 26, 'p002'),
(98, 'TVS Apachi 200', 'Brajesh_74.jpg', 2052580000, 34, 'p003'),
(129, 'Suzzuki 300R', 'suzuki_300R.jpg', 536788, 10, 'p096'),
(130, 'Sumsung_crexy fan', 'fan-oriental.jpg', 1200, 0, 'p001'),
(128, 'Super bike ', 'Brajesh_76.jpg', 35747, 34, 'p000'),
(111, 'Yamaha cbz23', 'Suzuki20GSXR.jpg', 8700060, 34, 'p001'),
(105, 'BAZZAZ BOXER23', 'Kawasaki.jpg', 120046000, 45, 'p001');

-- --------------------------------------------------------

--
-- Table structure for table `slider_banner`
--

CREATE TABLE `slider_banner` (
  `banner_id` int(5) NOT NULL,
  `banner_name` varchar(100) NOT NULL,
  `ban_images` varchar(50) NOT NULL,
  `ban_price` int(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `slider_banner`
--

INSERT INTO `slider_banner` (`banner_id`, `banner_name`, `ban_images`, `ban_price`) VALUES
(1, 'Suzzuki Yamaha bike', 'Kawasaki.jpg', 3206000),
(2, 'Nokia N Serise', 'nokia.jpg', 10500),
(3, 'Mobile Android', 'mobile-andoried.jpg', 60500),
(4, 'Dell Laptop of Mac', 'laptop-php-mac.jpg', 45500);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adm_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shoppcart`
--
ALTER TABLE `shoppcart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slider_banner`
--
ALTER TABLE `slider_banner`
  ADD PRIMARY KEY (`banner_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adm_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `shoppcart`
--
ALTER TABLE `shoppcart`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=132;
--
-- AUTO_INCREMENT for table `slider_banner`
--
ALTER TABLE `slider_banner`
  MODIFY `banner_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
