<?php 
   // Create connection
	$con = mysqli_connect("localhost","cotocus");
	 mysqli_select_db($con,"shopping") or die ("Check connection");
				
	 // Check connection
	/*if($con){echo "connection is succussefully";  }
	  else{echo "not connected";}*/
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>My Shopping </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <!-- jQuery library -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <!-- Popper JS -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <!-- Latest compiled JavaScript -->
  <script src='https://kit.fontawesome.com/a076d05399.js'></script>
  <!--slider start---->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  <!--slider end---->
</head>
<body>
	<nav class="navbar navbar-expand-md bg-primary navbar-dark">
	  <a class="navbar-brand" href="index.php"><h3><i class="fas fa-gift text white">&nbsp;&nbsp;My shopping</i></h3></a>
	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
		<span class="navbar-toggler-icon"></span>
	  </button>
	  <form action="" method="post" style="margin-left:250px; background-color:red; border:3px solid orange; border-radius:5px;font-weight:bold;">
			 <input type="text" name="Sear" placeholder="Search Product OR Price"/>
			 <input type="submit" name="Search" class="bg-warning text-white font-weight-bold" value="Search"/>
	  </form>
	  <div class="collapse navbar-collapse" id="collapsibleNavbar">
		<ul class="navbar-nav ml-auto">
		  <li class="nav-item">
			<a class="nav-link active text-white" href="index.php"><b>Products</b></a>
		  </li>
		  <li class="nav-item">
			<a class="nav-link text-white" href="index.php"><b>Categories</b></a>
		  </li>
		  <li class="nav-item">
			<a class="nav-link text-white" href="checkout.php"><b>Checkout</b></a>
		  </li>
		  <li class="nav-item">
			<a class="nav-link" href="view_cart.php">
			  <i class="fas fa-shopping-cart" style="font-size:30px; color:orange"></i>
			  <span class="badge badge-danger" id="cart-item" style="font-size:18px">2</span>
			</a>
		  </li> 
		</ul>
	  </div>  
	</nav>
    <div class="container-flud"><!---------container start 1--->
	    <div id="demo" class="carousel slide bg-warning" data-ride="carousel"> 

	        <!-- Indicators -->
		    <ol class="carousel-indicators">
			<?php
				$query = "SELECT `id`,`name`, `image`, `price`, `discount`, `p_code` FROM `shoppcart` order by id ASC";
				 $record=mysqli_query($con,$query);
				 $i=0;
				 foreach($record as $row){
					$actives ='';
					if($i==0){
						$actives='active'; 
					 }
							   
				?>
				<li data-target="#myCarousel" data-slide-to="<?php echo $i;?>" class="<?php echo $actives;?>"></li>
			 <?php $i++;}?>	
		     </ol>

			<!-- Wrapper for slides start-->
			<div class="carousel-inner">
			    <?php
				 $i=0;
				 foreach($record as $row){
					$actives ='';
					if($i==0){
						$actives='active'; 
					 }
							   
				?>
				<div class="carousel-item <?php echo $actives;?>">
					<img src="admin/images/<?php echo $row['image'];?>" alt="Kawasaki" height="150">
						<div class="carousel-caption">
							<h3><?php echo $row['name'];?></h3>
							<p>&#8377;<?php echo $row['price'];?>!</p>
						</div>
				</div>
				<?php $i++;}?>
            </div> <!-- Wrapper for slides end -->
     
			<!-- Left and right controls -->
			<a class="carousel-control-prev" href="#demo" data-slide="prev">
				<span class="carousel-control-prev-icon"></span>
			</a>
			<a class="carousel-control-next" href="#demo" data-slide="next">
				<span class="carousel-control-next-icon"></span>
			</a>
	
        </div><!-------carousel slide end------->
    </div><!-------container 1 end------->
    <div class="container"><!-------container start 2 ------->
        <div class="row">
		    <!------------Searching start------->
            <?php
			    
	            if(isset($_REQUEST['Search'])){ 
					$Sear = $_REQUEST['Sear'];
	            $query = "SELECT `id`,`name`, `image`, `price`, `discount`, `p_code` FROM `shoppcart`  WHERE name like '%".$Sear."%' OR price like'%".$Sear."%'";
	            $record_query = mysqli_query($con,$query);
	            $num = mysqli_num_rows($record_query);
	            if($num >0){
		        while($product = mysqli_fetch_array($record_query)){
			?> 
			<div class="col-lg-3 col-md-3 col-sm-12">
			    <form action="insert_cart.php" method="post">
			        <div class="card">
			            <h6 class="card-title bg-info text-white p-2 h-100"><b><?php echo $product['name'] ?></b></h6>
					    <div class="cord-body text-center text-danger w-75">
					        <img src="admin/images/<?php echo $product['image'] ?>" alt="phone" class="w-50 mb-2">
							<h6>&nbsp;&#8377;:<?php echo number_format($product['price'],2) ?>&nbsp;&nbsp;(<span><?php echo $product['discount'] ?> %</span> off)</h6>
							<h6 class="badge badge-success">4.4<i class="fa fa-star"></i></h6>
								<input type="hidden" name="name" value="<?php echo $product['name'];?>" class="form-control">
								<input type="hidden" name="price" value="<?php echo $product['price'];?>" class="form-control">
								<input type="text" name="qty" class="form-control" value="1"placeholder="quantity">
							
						</div>
						<div class="w-100">
							<button class="btn-success flex-fill w-50"><b>Add to cart</b></button><button class="btn-warning flex-fill w-50"><a class="text-white" href="insert_cart.php?id=<?php $product['id']?>"><b>BUy Now</b></a></b></button>
						</div>	 
			        </div>
			    </form>
			</div>
            <?php
			  
		       }
		        
	          }
			  else {echo ("Not Data Match!, Tri again");}
			} 
            ?>
			<!------------Searching end------->
			<!--***********************************************----->
			<!------------index producs of view------->
			<?php if(!isset($_REQUEST['Search']) && (!isset( $_REQUEST['Sear']))){ 
			  $query = "SELECT `id`,`name`, `image`, `price`, `discount`, `p_code` FROM `shoppcart` order by id ASC";
	            $record_query = mysqli_query($con,$query);
	            $num = mysqli_num_rows($record_query);
	            if($num >0){
		        while($product = mysqli_fetch_array($record_query)){
			?> 
			<div class="col-lg-3 col-md-3 col-sm-12">
			    <form action="insert_cart.php" method="post">
			        <div class="card">
			            <h6 class="card-title bg-info text-white p-2 h-100"><b><?php echo $product['name'] ?></b></h6>
					    <div class="cord-body text-center text-danger w-75">
					        <img src="admin/images/<?php echo $product['image'] ?>" alt="phone" class="w-50 mb-2">
							<h6>&nbsp;&#8377;:<?php echo number_format($product['price'],2) ?>&nbsp;&nbsp;(<span><?php echo $product['discount'] ?> %</span> off)</h6>
							<h6 class="badge badge-success">4.4<i class="fa fa-star"></i></h6>
								<input type="hidden" name="name" value="<?php echo $product['name'];?>" class="form-control">
								<input type="hidden" name="price" value="<?php echo $product['price'];?>" class="form-control">
								<input type="text" name="qty" class="form-control" value="1"placeholder="quantity">
							
						</div>
						<div class="w-100">
							<button class="btn-success flex-fill w-50"><b>Add to cart</b></button><button class="btn-warning flex-fill w-50"><a class="text-white" href="insert_cart.php?id=<?php $product['id']?>"><b>BUy Now</b></a></b></button>
						</div>	 
						
			        </div>
			    </form>
			</div>
            <?php			
		       } 
               
	          }
			}
			?>
	    </div>
	</div><!---container end 2---->
	<div class="container-flud"><!-------container start 3------->
		<div id="demo" class="carousel slide bg-primary" data-ride="carousel"> 

	        <!-- Indicators -->
		    <ol class="carousel-indicators">
			<?php
				$sql="SELECT * FROM `slider_banner`";
	            $record=mysqli_query($con,$sql);
				
				 $i=0;
				 foreach($record as $row){
					$active ='';
					if($i==0){
						$active='active'; 
					 }
							   
				?>
				<li data-target="#myCarousel" data-slide-to="<?php echo $i;?>" class="<?php echo $active;?>"></li>
			 <?php $i++;}?>	
		     </ol>

			<!-- Wrapper for slides start-->
			<div class="carousel-inner">
			    <?php
				 $i=0;
				 foreach($record as $row){
					$active ='';
					if($i==0){
						$active='active'; 
					 }
							   
				?>
				<div class="carousel-item <?php echo $active;?>">
					<img src="banner/<?php echo $row['ban_images'];?>" alt="Kawasaki" height="150">
						<div class="carousel-caption">
							<h3><?php echo $row['banner_name'];?></h3>
							<p>&#8377;<?php echo $row['ban_price'];?>!</p>
						</div>
				</div>
				<?php $i++;}?>
            </div> <!-- Wrapper for slides end -->
     
			<!-- Left and right controls -->
			<a class="carousel-control-prev" href="#demo" data-slide="prev">
				<span class="carousel-control-prev-icon"></span>
			</a>
			<a class="carousel-control-next" href="#demo" data-slide="next">
				<span class="carousel-control-next-icon"></span>
			</a>
	
        </div><!-------carousel slide end------->
    </div><!-------container  end 3------>
</body>
</html>
	