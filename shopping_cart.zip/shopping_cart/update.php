
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Update Product </title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>

    <div class="jumbotron bg-warning text-center">
       <h1 class="text-white mb-5" style="font-family:'abrial fatface';"><b>YOU CAN UPDATE PRODUCTS FOR SELLING  </b></h1>
    </div>

<div class="container col-sm-7">
<?php
		// Create connection
		$con = mysqli_connect("localhost","cotocus");
		mysqli_select_db($con,"shopping");
		// Check connection
	  
	     if($con){
	           echo "";  
	        }
	      /* else{
	          echo "not connected";
	       }*/

		$upd = @$_GET['upd'];
		
        $edit_query = "SELECT `name`, `image`, `price`, `discount` FROM `shoppcart` where id ='$upd'";
		$edit_data = mysqli_query($con,$edit_query);
		while($row = mysqli_fetch_array($edit_data)){
			
			$upd_name = $row['name'];
			$upd_image = $row['image'];
			$upd_price = $row['price'];
			$upd_discount = $row['discount'];		
		}

	if(isset($_POST['update'])){
		
			$pro_name =$_POST['name'];
			$pro_image =$_FILES['image']['name'];
			$file_tmp =$_FILES['image']['tmp_name'];
			$pro_price =$_POST['price'];
		    $pro_dis =$_POST['discount'];
				//uploading images to its folder
				$location='images/'.$pro_image;
				move_uploaded_file($file_tmp,$location);
				
				$products="UPDATE `shoppcart` SET `id`='$upd',`name`='$pro_name',`image`='$pro_image',`price`='$pro_price',`discount`='$pro_dis' WHERE id='$upd'";
				$udate =mysqli_query($con, $products); 
				//if (mysqli_query($con, $products)){}
                if($udate){	
					echo header('location:view_page.php');
				} 
			    else {
					
				   echo "Error: " .$products . "<br>" . mysqli_error($con);
				}
			
	}
	
mysqli_close($con);

?>
	<form class="col-sm-12"action="upd.php?upd=<?php echo $upd; ?>" method="post" enctype="multipart/form-data">
			<div class="form-group">
			  <label for="name">Product Name:</label>
			  <input type="text" class="form-control" placeholder="Product name" value="<?php echo $upd_name;?>" name="name">
			</div>
			<div class="custom-file">
				<input type="file" class="custom-file-input" id="customFile" name="image/"><img src="images/<?php echo $upd_image;?>" alt="phone" width="100" height="60">
				<label class="custom-file-label" for="customFile">Choose file</label>
			</div>
			<div class="form-group">
			  <label for="price">Product Price:</label>
			  <input type="text" class="form-control" id="price" value="<?php echo $upd_price;?>" name="price">
			</div>
			<div class="form-group">
			  <label for="discount">Discount Price:</label>
			  <input type="text" class="form-control" id="discount" value="<?php echo $upd_discount;?>" name="discount">
			</div>
			<input type="submit" class="btn btn-primary" value="Update" name="update">
			
		</form>	
		 
        <script>
			// Add the following code if you want the name of the file appear on select
			$(".custom-file-input").on("change", function() {
			  var fileName = $(this).val().split("\\").pop();
			  $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
			});
	    </script>
   </div>
</body>
</html>