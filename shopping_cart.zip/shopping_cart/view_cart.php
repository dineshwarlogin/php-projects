<?php
   session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>View Cart/My shopping </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <!-- jQuery library -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <!-- Popper JS -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <!-- Latest compiled JavaScript -->
  <script src='https://kit.fontawesome.com/a076d05399.js'></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
 
</head>
<body>
	<nav class="navbar navbar-expand-md bg-primary navbar-dark">
	  <a class="navbar-brand" href="index.php"><h3><i class="fas fa-gift text white">&nbsp;&nbsp;Home</i></h3></a>
	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
		<span class="navbar-toggler-icon"></span>
	  </button>
	  <div class="collapse navbar-collapse" id="collapsibleNavbar">
		<ul class="navbar-nav ml-auto">
		  <li class="nav-item">
			<a class="nav-link active text-white" href="index.php"><b>Products</b></a>
		  </li>
		  <li class="nav-item">
			<a class="nav-link text-white" href="index.php"><b>Categories</b></a>
		  </li>
		  <li class="nav-item">
			<a class="nav-link text-white" href="checkout.php"><b>Checkout</b></a>
		  </li>
		  <li class="nav-item">
			<a class="nav-link" href="view_cart.php">
			  <i class="fas fa-shopping-cart" style="font-size:30px; color:orange"></i>
			  <span class="badge badge-danger" id="cart-item" style="font-size:18px">2</span>
			</a>
		  </li> 
		</ul>
	  </div>  
	</nav><br>
   <h2 style="margin-left:500px;"><b>Your Cart Products!</b></h2><br>
<div class="container">
	<table class="table table-bordered">
		<thead class="btn-dark text-left">
			  <tr>
			    <th>Serial N.</th>
				<th>Name</th>
				<th>Price</th>
				<th>Quntity</th>
				<th>Sub Totale</th>
				<th>Update</th>
				<th>Delete</th>
			  </tr>
		</thead>
		<tbody>
    <?php
		$sub_totale=0;
		$totale =0;
	    $ser=1;
		foreach($_SESSION as $prds){		
			$p=0;
			$q=0;		
			echo "<tr>";
			    echo "<td width='90'>".($ser++)."</td>";
			    echo '<form action="cart_edit.php" method="post">';
				foreach($prds as $key => $val){
					if($key == 2){ 
						echo "<td width='20'><input type='text' name='qty$key' class='form-control' value='".$val."'></td>";
						$q = $val;
					}
					else if($key == 1){
					     echo "<input type='hidden' name='price$key' value='".$val."'>";
						 echo "<td width='120' class='text-danger text-left'><b>&#8377;".$val."<b></td>";
						 $p = $val;
					}
					else if($key == 0){
							echo "<input type='hidden' name='name$key' value='".$val."'>";
                            echo "<td width='200' class='text-danger text-left'><b>".$val."</b></td>";							
					}
				} 
				$sub_totale = $q * $p;
                echo "<td width='160' class='text-danger text-left'><b>&#8377;".$sub_totale."</td>";
                echo '<td width="20" class="text-left"><input type="submit" name="event" value="Update" class="btn btn-primary text-white font-weight-bold"></td>';
				echo '<td width="20" class="text-left"><input type="submit" name="event" value="Delete" class="btn btn-danger text-white font-weight-bold"></td>';
				echo"</form>";
			echo "</tr>";
			
			  $totale += $sub_totale;
		}
			echo "<tr>";
				  echo'<td class="text-right" colspan="4"><b><input type="submit" name="Checkout" value="Checkout" class="btn btn-success font-weight-bold"></b></td>';
				  echo '<td width="210" colspan="1"><b>Totale Amount: </b><b class="text-danger">&#8377;'.$totale.'</b></td>';
				  echo '<td colspan="2"><h4 class="font-weight-bold text-center"><a href="index.php">Continue Shopping</a></h2></td>';
			echo "</tr>";
		
	?>
			</tbody>   		
		</table>
    </div>     
</body>
</html>
