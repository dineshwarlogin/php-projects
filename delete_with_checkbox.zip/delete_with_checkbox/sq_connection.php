<?php
        // Create connection in mysql_connect
	/*
	$con = mysql_connect("localhost","cotocus");
	mysql_select_db($con,"mini_project");
		//Check connection
		if($con){
		    echo "connection is succussefully";  
		}
		else{
			echo "not connected";
		}
	*/	
	     // OR
		 
		 
	   // Create connection in mysqli_connect
	
		$con = mysqli_connect("localhost","root","","mini_project");
		//Check connection
		if(!$con){
		    echo "Its not connected !";  
		}
		
?>