
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Delete with checkbox</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1"> 
   <link rel="stylesheet" type="text/css" href="style.css"/>
  </head>
<body><h2>Display and Delete with checkbox!</h2>
   <form  action="index.php" method="post">
	<table>
	  	
			<tr>
				<th>Id</th>
				<th>Name</th>
				<th>Email</th>
				<th>Gender</th>
				<th>Message</th>
				<th>City</th>
				<th>Language</th>
				<th><input type="submit" name="Delt" value="Delete" onclick="return confirm('Are you sure to Delete')"/></th>
			</tr>
	    <?php
		    include("sq_connection.php");
	
	        if((isset($_POST['Delt'])) and (isset($_POST['check']))){
						$check =$_POST['check'];
						$chk =implode(",",$check);

						$query="DELETE FROM person WHERE per_id in($chk)";
						mysqli_query($con,$query);
						echo "<script>alert('Data has been deleted!');</script>";
		    }
						
			
				       $sql="SELECT * FROM person ORDER BY per_id DESC";				
			           $count=mysqli_query($con,$sql);
			
				
			           $num=mysqli_num_rows($count);
				   
			           if($num >0){
			           while($row = mysqli_fetch_array($count)){
			?>
			<tr>
			    <td><?php echo $row['per_id'];?></td>
				<td><?php echo $row['uname'];?></td>
				<td><?php echo $row['eml'];?></td>
				<td><?php echo $row['gender'];?></td>
				<td><?php echo $row['mess'];?></td>
				<td><?php echo $row['city'];?></td>
				<td><?php echo $row['language'];?></td>
			    <td><input type="checkbox" name="check[]" value="<?php echo $row['per_id'];?>"/></td>
		    </tr>
					
			<?php 
			  }
		     }
             echo "<script>alert('Select at lest 1 Record!');</script>";			  
			 	 
			?>
			
	</table>
	</form>
  </body>
</html>