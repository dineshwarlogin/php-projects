<?php
        // Create connection in ------>mysql_connect
	/*
		
	$con = mysql_connect("localhost","root","");
	mysql_select_db($con,"mini_project");
	
	//Check connection
		if(!$con){
		    echo "It's connected";  
		}else{
			echo "Not connected";
		}
	*/
	
	// Create connection in ------>mysqli_connect
	
	$con = mysqli_connect("localhost","root","","mini_project");
		//Check connection
		if(!$con){
		    echo "not connected";  
		}
		//else{echo "It is connected!";}
		
		
?>