<?php
        // Create connection
	$con = mysqli_connect("localhost","root","");
	mysqli_select_db($con,"mini_project");
		//Check connection
		if(!$con){
		    echo "no connected";  
		}
		//else{echo "not connected";}
		
		
?>