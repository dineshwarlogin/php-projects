<?php
error_reporting(0); 
include("sq_connection.php");
	    $name=''; 
	    $pass=''; 
	    $conf_ps='';
		$city_name='';
	    $mob='';
		$gender='';
    if(isset($_POST["submit"])){

	    $name =$_POST["name"];
		$pass =($_POST["pass"]);
		//$pass=md5($pass);
		$conf_ps =$_POST["conf_pass"];
		$city_name =$_POST["city_name"];
		$mob =$_POST["mob_n"];
		$gender =$_POST["gender"];
		
			if(empty($name)){
				$er_name="Name is requred!";
			}
			elseif((strlen($name)<=2) OR (strlen($name)>=26)){
					$str_lenth="Mini 3 chrecters and Maxi 25 allowed!";		
			}
			elseif(!preg_match('/^[a-zA-Z ]*$/', $name)){
				  $str_name="Only latters allowed!";	  
			}
          //-------------------------------------------Password star
		      
			elseif(empty($pass)){
				$error_pass="Password is Required";
			}
			elseif((strlen($pass)<=5) OR (strlen($pass)>=11)){
					$pass_lenth="Mini 6 lenth of password and Maxm 10!";
			}
			         //------------------------Confirm Password start
			elseif(empty($conf_ps)){
				$error_conf=" password is Required!";
			}
			elseif($conf_ps!== $pass){
			
				$vfy_pass="Please confirm password!";
			}
			
			//-------------------------------Password end------------>
			elseif(empty($city_name)){
				$err_city="City is Required!";	
			}    //-----------------Mobile num start------>
			elseif(empty($mob)){
				$er_mob="Mobile number is Required!";
			}
			elseif(!preg_match('/^[0-9]*$/',$mob)){
						$mob_err="Onlly allowed Mobile numbers!";
			}
			elseif((strlen($mob)<10) OR (strlen($mob)>10)){
							$mob_lenth="10 Digit Mobile numbers allowed!";
			}
					//-----------------Mobile num end------>
			elseif(empty($gender)){
				$err_gend="Gender at lest one Required!";
			}
	  
			else{
				$form_query="INSERT INTO `data`(`name`, `pass`, `conf_pass`, `city_name`, `mob_n`, `gender`) VALUES ('$name','$pass','$conf_ps','$city_name','$mob','$gender')";
		       mysqli_query($con,$form_query);
				
				echo "<script>alert('Data has been submited')</script>";
				$succses="Data has been inserted Succsesfully !";  	
			}
	}
	else{
		echo "<script>alert('Not submited')</script>";	
	}   			
	
?>
<!DOCTYPE HTML>  
<html>
<head>
<title>Validate Form Dynamic</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1"/> 
<link rel="stylesheet" type="text/css" href="css/style.css"/>
</head>
<body>  
<h2>Fully Dynamically Validate Form</h2>
<form align="center" method="POST" action="index.php"> 
   <p id="succses"> <?php if(isset($succses)) {echo $succses;}?></p>
  <label>User Name: <input type="textbox" name="name" value="<?php echo $name;?>" placeholder="User Name" autocomplete="off"/>
     &nbsp;&nbsp;<span id="error">
	 <?php
	    if(isset($er_name)){
			echo $er_name;
		}
		elseif(isset($str_lenth)){
		   echo $str_lenth;
	    }
		
	    elseif(isset($str_name)){
		   echo $str_name;
	    }
        
	 ?>
	 </span>
  </label>
  <br/><br/>
  <label>Password: <input type="password" name="pass" value="<?php echo $pass;?>" placeholder="password" autocomplete="off"/>
    &nbsp;&nbsp;<span id="error"><?php if(isset($error_pass)){echo $error_pass;} elseif(isset($pass_lenth)){ echo $pass_lenth;} ?></span>
  </label>
  <br/><br/>
  <label>Confirm Password: <input type="password" name="conf_pass" value="<?php echo $conf_ps;?>" placeholder="confirm password" autocomplete="off"/>
    &nbsp;&nbsp;<span id="error">
	<?php 
	if(isset($error_conf)){ 
	    echo $error_conf;
	} 
	elseif(isset($vfy_pass)){ 
	     echo $vfy_pass;
	} ?>
	</span>
  </label>
  <br/><br/>
  <label>
	City:<select name='city_name'>
            <option value=''>Selesct City</option>
	<?php
	$arr_citys=array('Ranchi','Bokaro','Patna','Delhi','Mumbai','Kolkata','Chenai','Lakhnou','Bangolor','Hydrabad','Pune','Raipur','Bhopal','Jipur','Guwahati','Itanagar','Imphal','Sinong','Secondrabad','Modoroi','Kohima','Agertala',);
	  sort($arr_citys);
		foreach($arr_citys as $citys){
			    //$isSelected="";
			 if($city_name==$citys){
				 //$isSelected="selected";
				echo "<option selected>".$citys."</option>";
			 }else{
				 echo "<option>".$citys."</option>";
			 }
		}
	?>
         		   
        </select>
        &nbsp;&nbsp;<span id="error"><?php if(isset($err_city)){echo $err_city;} ?></span>
	</label>
	<br/><br/>
	<label>
		Mobile N: <input type="mobile" name="mob_n" value="<?php echo $mob;?>" placeholder="Mobile N" autocomplete="off"/>
	    &nbsp;&nbsp;<span id="error"><?php if(isset($er_mob)){echo $er_mob;} elseif(isset($mob_err)){echo $mob_err;} elseif(isset($mob_lenth)){echo $mob_lenth;} ?></span>
	</label>
  <label>
	<p>Select Gender Bellow!:</p>
   <?php 
           
		$aray_gender = array('Male','Female','Other');
		foreach($aray_gender as $list){
			 if(in_array($list, $gender)){
				 echo $list."<input type='radio' name='gender' value='$list' checked='$gender'/>";
			 }
			 else{
				 echo $list."<input type='radio' name='gender' value='$list' checked='$gender'/>";
			 }
		}
   ?>
	
     &nbsp;&nbsp;<span id="error"><?php if(isset($err_gend)){echo $err_gend;}?></span>   
  </label>
  <br/><br/>
  <input type="submit" name="submit" value="Submit" id="sub"/>
  <input type="submit" value="Referece" name="Referece" id="sub"/>  
</form>
</body>
</html>