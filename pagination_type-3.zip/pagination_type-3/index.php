<?php
$con=mysqli_connect("localhost","root","","mini_project");
if(!$con){
 echo"Coneection is Field";
}
//----------------------------------------
   
    $per_page = 5;
	$start=0;
	$current_page=1;
	if(isset($_GET['start'])){
		$start=$_GET['start'];
		if($start<=0){
			$start=0;
			$current_page=1;
		}
		else{
		   $current_page=$start;
		   $start--;
		   $start=$start*$per_page;
		}
	}
	
	$total = "SELECT COUNT(*) FROM  data";
    $result = mysqli_query($con,$total);
    $total_rows = mysqli_fetch_array($result)[0];
    $total_pages = ceil($total_rows/$per_page);
	
    $sql = "SELECT * FROM data LIMIT $start,$per_page";
    $res_data = mysqli_query($con,$sql);
    // Prev + Next
  $prev = $current_page - 1;
  $next = $current_page + 1;    
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>paginatin type 3</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  
</head>
<body>

<div class="container">
  <h5>Totale Record: <?php echo $total_rows;?><br/>Totale Pages: <?php echo $total_pages;?></h5> 
  <table class="table danger">
    <thead>
      <tr class="info">
        <th>Id</th>
        <th>Name</th>
        <th>Pass</th>
		<th>Conf_Pass</th>
		<th>city</th>
		<th>Mobile</th>
		<th>Gender</th>
      </tr>
    </thead>
    <tbody>
	<?php 
	    if(mysqli_num_rows($res_data)>0){
		  
	        while($row = mysqli_fetch_array($res_data)){
	?>
            
      <tr class="warning">
        <td><?php echo $row['dada_id'];?></td>
        <td><?php echo $row['name'];?></td>
        <td><?php echo $row['pass'];?></td>
		<td><?php echo $row['conf_pass'];?></td>
		<td><?php echo $row['city_name'];?></td>
		<td><?php echo $row['mob_n'];?></td>
		<td><?php echo $row['gender'];?></td>
		
      </tr> 
		<?php }}  else { echo "No recordS";}?>	  
    </tbody>
  </table>
  
<ul class="pagination">
    <li class="page-item <?php if($current_page <= 1){ echo 'disabled'; } ?>">
        <a class="page-link"
            href="<?php if($current_page <= 1){ echo '#'; } else { echo "?start=" . $prev; } ?>">Previous</a>
    </li>
    <?php
	
	for($i=1;$i<=$total_pages;$i++){
		$class='';
		if($current_page==$i){
			$class='active';
		}
		
	?>
	<li class="page-item <?php echo $class;?>"><a class="page-link" href="?start=<?php echo $i;?>"><?php echo $i;?></a></li>
	<?php } ?>
	<li class="page-item <?php if($current_page >= $total_pages) { echo 'disabled'; } ?>">
        <a class="page-link"
                href="index.php<?php if($current_page >= $total_pages){ echo '#'; } else {echo "?start=". $next; } ?>">Next</a>
    </li>
	
</ul>
</div>

</body>
</html>