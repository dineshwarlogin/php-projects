<?php 
			       
		$con = mysqli_connect("localhost","cotocus");
	    mysqli_select_db($con,"shopping") or die ("Check connection");
		$query = "SELECT `id`,`name`, `image`, `price`, `discount`, `p_code` FROM `shoppcart` order by id ASC";
		//$query="SELECT * FROM `slider_banner`";
	    $record=mysqli_query($con,$query);
	    //$count=mysqli_num_rows($record);
	    //while($rows=mysqli_fetch_array($count)){ }    
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Dynamic Slider Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Carousel Example</h2>
  <div id="myCarousel" class="bg-primary carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
	    <?php
		 $i=0;
		 foreach($record as $row){
			$actives ='';
			if($i==0){
				$actives='active'; 
			 }
					   
		?>
            <li data-target="#myCarousel" data-slide-to="<?php echo $i;?>" class="<?php echo $actives;?>"></li>
		 <?php $i++;}?>	
    </ol>

			<!-- Wrapper for slides -->
			<div class="carousel-inner">
			    <?php
				 $i=0;
				 foreach($record as $row){
					$actives ='';
					if($i==0){
						$actives='active'; 
					 }
							   
				?>
				<div class="item <?php echo $actives;?>">
					<img src="admin/images/<?php echo $row['image'];?>" alt="Kawasaki" height="200">
						<div class="carousel-caption">
							<h3><?php echo $row['name'];?>!</h3>
							<p>&#8377; <?php echo $row['price'];?></p>
						</div>
				</div>
				<?php $i++;}?>
          </div><!-- Wrapper for slides end -->
     
    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
	
  </div>
</div>
</body>
</html>
