<?php
        // mysql_connect connection 
	/*
		$con = mysql_connect("localhost","cotocus");
		mysql_select_db($con,"mini_project");
			if($con){
				echo "connection is succussefully";  
			}
			else{
				echo "not connected";
			}
		*/	
		// mysqli_connect connection start
	$con = mysqli_connect("localhost","root","","mini_project");
		//Check connection
		if(!$con){
		    echo "Not connected!";  
		}
		
?>