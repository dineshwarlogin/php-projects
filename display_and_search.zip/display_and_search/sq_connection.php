<?php
        // Create connection
	$con = mysqli_connect("localhost","cotocus");
	mysqli_select_db($con,"shopping");
		//Check connection
		if($con){
		    echo "connection is succussefully";  
		}
		else{
			echo "not connected";
		}
?>