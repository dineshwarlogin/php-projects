<!DOCTYPE html>
<html lang="en">
<head>
  <title>Search ||Delete with Cheack Box</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1"> 
  <style>
  
  table{background-color:SlateBlue; border-style:solid; border-width:7px; text-align:center; margin-left:400px;}
  th {
  background-color:#ff6347; border-width:5px; text-align:center; border-width:5px; padding:10px;text-color:white;
}
td{
  background-color:#4CAF; border-style:solid; border-width:5px; text-align:center;padding:text-color:white;
}
h2{text-align:center; color:SlateBlue; font-size:25px;}
input{height:28px; border: 2px solid SlateBlue ; border-radius: 5px; text-align:center;}
  </style>
  </head>

<body><h2>Display  And Search Record</h2>		
	<form method="post" action="">
	  <table>
		  <tr>
			<th><form method="post" action="search.php">  
			<input type="text" name="srch" placeholder=" Name or City">
			<input type="submit" name="sch" value="Search">  
			</form></th>
		 </tr>
		 <tr>
			<th>Id</th>
			<th>Name</th>
			<th>Mobile</th>
			<th>Email</th>
			<th>City</th>
		 </tr>
	 
	    <?php
		   include("sq_connection.php");

			if(isset($_REQUEST['sch'])){
				 
				 $srch=$_REQUEST['srch'];	 
			$sql="SELECT * FROM del WHERE city like '%".$srch."%' OR use_name like'%".$srch."%'";	
			$count=mysqli_query($con,$sql);
			//$num = mysqli_fetch_array($count);
			}
			else{		
			$sql="SELECT * FROM del";
			$count=mysqli_query($con,$sql);
			//$num = mysqli_fetch_array($count);
			}
	    ?>
		<?php 
			 while($row = mysqli_fetch_array($count)){
			 								
          ?>
		  <tr>
			<td><?php echo $row['de_id'];?></td>
				<td><?php echo $row['use_name'];?></td>
			<td><?php echo $row['mob'];?></td>
			<td><?php echo $row['eml'];?></td>
			<td><?php echo $row['city'];?></td>
		  </tr>
			<?php } ?>
	  </table>
	</form>
  </body>
</html>