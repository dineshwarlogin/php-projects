<!DOCTYPE html>
<html lang="en">
<head>
  <title>Search and Display</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1"> 
  <link rel="stylesheet" href="style.css"/>
  </head>

<body>	
	<form method="post" action="">
	  <table>
		  <tr>
			<th>
			<form method="post" action="search.php">  
			  <input type="text" name="srch" placeholder=" Name or City">
			   <input type="submit" name="sch" value="Search">  
			</form>
			</th>
			<th colspan="6"><h2>Display  And Search Record</h2></th>
		 </tr>
		 <tr>
			<th>Id</th>
			<th>Name</th>
			<th>Email</th>
			<th>Gender</th>
			<th>Message</th>
			<th>City</th>
			<th>Language</th>
		 </tr>
	 
	<?php
	include("sq_connection.php");

	if(isset($_REQUEST['sch'])){
				 
	$srch=$_REQUEST['srch'];
    $sql="SELECT * FROM `person` WHERE city like '%".$srch."%' OR uname like'%".$srch."%' OR language like'%".$srch."%' OR gender like'%".$srch."%'";	
	$count=mysqli_query($con,$sql);
			//$num = mysqli_fetch_array($count);
	}
	else{		
		$sql="SELECT * FROM person";
		$count=mysqli_query($con,$sql);
			//$num = mysqli_fetch_array($count);
		}
	    ?>
		<?php 
			 while($row = mysqli_fetch_array($count)){
			 								
          ?>
		  <tr>
			<td><?php echo $row['per_id'];?></td>
			<td><?php echo $row['uname'];?></td>
			<td><?php echo $row['eml'];?></td>
			<td><?php echo $row['gender'];?></td>
			<td><?php echo $row['mess'];?></td>
			<td><?php echo $row['city'];?></td>
			<td><?php echo $row['language'];?></td>
		  </tr>
			<?php } ?>
	  </table>
	</form>
  </body>
</html>