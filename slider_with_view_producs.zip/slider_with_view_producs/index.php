<html lang="en">
<head>
  <title>View products with slider </title>
  <meta charset="utf-8">
  <!-- Latest compiled JavaScript -->
  <script src='https://kit.fontawesome.com/a076d05399.js'></script>
  <!--slider start---->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
  <!--slider end---->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">

</head>
<body>
    <!------nav bar start/------->
		<nav class="navbar navbar-expand-md bg-primary navbar-dark">
		  <a class="navbar-brand" href="index.php"><h3><i class="fas fa-gift text white">&nbsp;&nbsp;Online Shoppe</i></h3></a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
			<span class="navbar-toggler-icon"></span>
		  </button>
		  <form action="search.php" method="post" style="margin-left:250px; background-color:red; border:3px solid orange; border-radius:5px;font-weight:bold;">
				 <input type="text" name="search" placeholder="Product Search"/>
				 <input type="submit" name="submit" class="bg-warning text-white font-weight-bold" value="Search"/>
		  </form>
		  <div class="collapse navbar-collapse" id="collapsibleNavbar">
			<ul class="navbar-nav ml-auto">
			  <li class="nav-item">
				<a class="nav-link active text-white" href="index.php"><b>Products</b></a>
			  </li>
			  <li class="nav-item">
				<a class="nav-link text-white" href="checkout.php"><b>Checkout</b></a>
			  </li>
			  <li class="nav-item">
				<a class="nav-link" href="cart_view.php">
				  <i class="fas fa-shopping-cart" style="font-size:30px; color:orange"></i>
				  <span class="badge badge-danger" id="cart-item" style="font-size:18px">0</span>
				</a>
			  </li> 
			</ul>
		  </div>  
		</nav>
	</nav>
   <!-------nave bar end ------->
 
    <div class="container">
		<div id="demo" class="bg-danger carousel slide " data-ride="carousel">
			<?php
				$conn = mysqli_connect("localhost","cotocus");
	            mysqli_select_db($conn,"shopping") or die ("Check connection");
			    $sql="SELECT * FROM `slider_banner`";
	            $record=mysqli_query($conn,$sql);
	            $count=mysqli_num_rows($record);  
			?>
	
			<!-- Wrapper for slides -->
			<div class="carousel-inner">
			    <?php
	           
			    for($i=1;$i<=$count; $i++){
					   $data = mysqli_fetch_array($record);
				?>
				<?php
				if($i == 1)
				 {	
				?>
				<div class="carousel-item active">
					<img src="banner/<?php echo $data['ban_images'];?>" alt="Kawasaki" height="200px">
						<div class="carousel-caption">
							<h3><?php echo $data['banner_name'];?></h3>
							<p>&#8377: <?php echo $data['ban_price'];?></p>
						</div>
				</div>
				<?php 
				 }
				 else
				 {
				?>
				 <div class="carousel-item">
					<img src="banner/<?php echo $data['ban_images'];?>" alt="Kawasaki" height="200px">
						<div class="carousel-caption">
							<h3><?php echo $data['banner_name'];?></h3>
							<p>&#8377: <?php echo $data['ban_price'];?></p>
						</div>
				</div>
				<?php }} ?>
			</div>
			
			<!-- Left and right controls -->
			<a class="carousel-control-prev" href="#demo" data-slide="prev">
                <span class="carousel-control-prev-icon"></span>
            </a>
            <a class="carousel-control-next" href="#demo" data-slide="next">
                <span class="carousel-control-next-icon"></span>
            </a>
			<?php}?>
		 </div>
	</div><!-------container end 1------->
	<div class="container"> <!-------container start 2------>
        <div class="row">
            <?php 
			   $con = mysqli_connect("localhost","cotocus");
	            mysqli_select_db($con,"shopping") or die ("Check connection");
				
			    $query = "SELECT `id`,`name`, `image`, `price`, `discount`, `p_code` FROM `shoppcart` order by id ASC";
	            $record_query = mysqli_query($con,$query);
	            $num = mysqli_num_rows($record_query);
	            if($num >0){
		        while($product = mysqli_fetch_array($record_query)){
			?> 
			<div class="col-lg-3 col-md-3 col-sm-12">
			    <form action="insert_cart.php" method="post">
			        <div class="card">
			            <h6 class="card-title bg-info text-white p-2 h-100"><b><?php echo $product['name']; ?></b></h6>
					    <div class="cord-body text-center text-danger w-75">
					        <img src="admin/images/<?php echo $product['image']; ?>" alt="phone" class="w-50 mb-2">
							<h6>&nbsp;&#8377;:<?php echo number_format($product['price'],2); ?>&nbsp;&nbsp;(<span><?php echo $product['discount'] ?> %</span> off)</h6>
							<h6 class="badge badge-success">4.4<i class="fa fa-star"></i></h6>
								<input type="hidden" name="name" value="<?php echo $product['name'];?>" class="form-control">
								<input type="hidden" name="price" value="<?php echo $product['price'];?>" class="form-control">
								<input type="text" name="qty" class="form-control" value="1"placeholder="quantity">
							
						</div>
						<div class="w-100">
							<button class="btn-success flex-fill w-50"><b>Add to cart</b></button><button class="btn-warning flex-fill w-50"><a class="text-white" href="insert_cart.php?id=<?php $product['id'];?>"><b>BUy Now</b></a></b></button>
						</div>	 
						
			        </div>
			    </form>
			</div>
            <?php			
		       } 
				
	          }
			?>
	    </div>
	</div><!-------container end 2------>
</body>
</html>