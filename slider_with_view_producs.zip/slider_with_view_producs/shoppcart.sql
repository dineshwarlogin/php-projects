-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 13, 2020 at 12:01 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shopping`
--

-- --------------------------------------------------------

--
-- Table structure for table `shoppcart`
--

CREATE TABLE `shoppcart` (
  `id` int(250) NOT NULL,
  `name` varchar(250) NOT NULL,
  `image` varchar(250) NOT NULL,
  `price` float NOT NULL,
  `discount` float NOT NULL,
  `p_code` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `shoppcart`
--

INSERT INTO `shoppcart` (`id`, `name`, `image`, `price`, `discount`, `p_code`) VALUES
(1, 'Sumsung galexy', 'mobile-andoried.jpg', 8950, 45, 'p001'),
(2, 'Nokia n serise', 'mobile-nokia.jpg', 15500, 25, 'p001'),
(3, 'Sonata ', 'watch-sonata.jpg', 1600, 30, 'p040'),
(4, 'Dell core_i3', 'laptop-php-mac.jpg', 45500, 15, 'p0109'),
(5, 'Karizma 255CC', 'karima.jpg', 160500, 14, 'p2080'),
(6, 'Redmi pro-9', 'redmi_pro_9.jpg', 16500, 18, 'p030'),
(7, 'Nokia Kepaid', 'nokia.jpg', 1850, 16, 'p801'),
(8, 'Sumsung Icore', 'Apple_iPhone.jpg', 34600, 15, 'p010'),
(34, 'Corex Yamaha', '03gd.jpg', 95650, 5, 'p0201'),
(33, 'Farari xgen', '10fdhs.jpg', 3250050, 8, 'p230'),
(66, 'Maruti xzn', 'BMW.gif', 1500800, 15, 'p200'),
(67, 'Maruti suzzuki Alto ', '.XUVI.gif', 980500, 6, 'p90'),
(73, 'Tata Somo', '11.JPG', 1609050, 20, 'p200'),
(74, 'Sentro Xgen 100', 'LOTUS_ELISE_1.JPG', 6700400, 36, 'p0020'),
(87, 'Farari st20', 'Ferrari1.jpg', 105000, 34, 'p0101'),
(88, 'XUV xgen ', 'CAR1A.JPG', 2008000, 23, 'p010'),
(90, 'Pulser 20HK', '8-1.JPG', 152581000, 73, 'p0000'),
(96, 'Suzzuki super bike', 'Brajesh_73.jpg', 2052580000, 26, 'p002'),
(98, 'TVS Apachi 200', 'Brajesh_74.jpg', 2052580000, 34, 'p003'),
(129, 'Suzzuki 300R', 'suzuki_300R.jpg', 536788, 10, 'p096'),
(130, 'Sumsung_crexy fan', 'fan-oriental.jpg', 1200, 0, 'p001'),
(128, 'Super bike ', 'Brajesh_76.jpg', 35747, 34, 'p000'),
(111, 'Yamaha cbz23', 'Suzuki20GSXR.jpg', 8700060, 34, 'p001'),
(105, 'BAZZAZ BOXER23', 'Kawasaki.jpg', 120046000, 45, 'p001');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `shoppcart`
--
ALTER TABLE `shoppcart`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `shoppcart`
--
ALTER TABLE `shoppcart`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=132;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
