<?php
$con=mysqli_connect("localhost","root","","mini_project");
if(!$con){
 echo"Coneection is Field";
}
else{
	if(isset($_GET['pageno'])) {
            $pageno = $_GET['pageno'];
    } 
	else{
        $pageno = 1;
    }
    $no_of_records_per_page = 6;
    $offset = ($pageno-1) * $no_of_records_per_page;
	
	$total_pages_sql = "SELECT COUNT(*) FROM  data";
    $result = mysqli_query($con,$total_pages_sql);
    $total_rows = mysqli_fetch_array($result)[0];
   $total_pages = ceil($total_rows / $no_of_records_per_page);
   
   $sql = "SELECT * FROM data LIMIT $offset, $no_of_records_per_page";
        $res_data = mysqli_query($con,$sql);
        
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>paginatin</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Pagination Dynamical in php</h2>
  <table class="table">
    <thead>
      <tr>
        <th>Id</th>
        <th>Name</th>
        <th>Pass</th>
		<th>Conf_Pass</th>
		<th>city</th>
		<th>Mobile</th>
		<th>Gender</th>
      </tr>
    </thead>
    <tbody>
	  <?php while($row = mysqli_fetch_array($res_data)){?>
            
      <tr class="success">
        <td><?php echo $row['dada_id'];?></td>
        <td><?php echo $row['name'];?></td>
        <td><?php echo $row['pass'];?></td>
		<td><?php echo $row['conf_pass'];?></td>
		<td><?php echo $row['city_name'];?></td>
		<td><?php echo $row['mob_n'];?></td>
		<td><?php echo $row['gender'];?></td>
		
      </tr> 
      <?php }}?>	  
    </tbody>
  </table>
  <ul class="pagination">
    <li><a href="?pageno=1">First</a></li>
    <li class="<?php if($pageno <= 1){ echo 'disabled'; } ?>">
        <a href="<?php if($pageno <= 1){ echo '#'; } else { echo "?pageno=".($pageno - 1); } ?>">Prev</a>
    </li>
    <li class="<?php if($pageno >= $total_pages){ echo 'disabled'; } ?>">
        <a href="<?php if($pageno >= $total_pages){ echo '#'; } else { echo "?pageno=".($pageno + 1); } ?>">Next</a>
    </li>
    <li><a href="?pageno=<?php echo $total_pages; ?>">Last</a></li>
</ul>
</div>

</body>
</html>