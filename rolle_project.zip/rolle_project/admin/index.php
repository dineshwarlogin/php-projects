<?PHP 
session_start();
?>
<!doctype html>
<html lang="en">
<head>
<title>login</title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>

<div style="margin-left:20%;margin-top:5%;margin-right:20%; border:5px solid gray;border-radius:15px; background-color:#00ff00;">
 <h1 align="center" style="background-color:#0066ff;border:1px solid #66ffff;border-radius:10px;">Admin Manager Here</h1>
<form method="post" action="index.php" style="margin:20px;padding:10px; background-color:#b300b3;">
  <div class="form-group">
    <label for="UserName">UserName</label>
    <input type="text" class="form-control" id="UserName" aria-describedby="emailHelp" name="username" placeholder="Enter UserName">
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" class="form-control" id="exampleInputPassword1" name="password" placeholder="Password">
  </div>
  <p style="color:white;"><b> I AM :</b> <b style="color:yellow;">
    <?php 
       $array_da = array('Admin','Manager','User');
	   $checked='';
	    foreach($array_da as $list){
		  $checked='checked=checked';
			if($list){
			 echo $list."<input type='radio'name='userName' value='$list' checked='$checked'/>|";	
			} 
			else{
			   echo $list."<input type='radio'name='userName' value='$list' checked='$checked'/>";
			} 
	    }
	?>
   <br/><br/></b></p>
  <input type="submit" name="login" class="btn btn-primary" value="Login-Here"/>
</form>
</div>
</body>
</html>
<?php
include("../mysql_connection/sql_connection.php");
if(isset($_POST['login'])){
	$username=$_POST['username'];
	$password=$_POST['password'];
	$userName=$_POST['userName'];
	
	$query="Select * From rolle Where username='$username' AND password ='$password' AND Rolle='$userName'";
	$data=mysqli_query($con,$query);
	$num=mysqli_num_rows($data);
	if($num>0){
		$_SESSION['username']= $username;
		echo"<script>alert('Login have succssefully!')</script>";
		echo"<script>window.open('../dashboard.php','_self')</script>";
		//header("location:../dashboard.php");
	}else{
		echo"<script>alert('Not login, please cheack userName And password With radio!')</script>";
        echo"<script>window.open('index.php','_self')</script>";
	}
}
?>