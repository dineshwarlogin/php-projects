<?php 
   $con=mysqli_connect("localhost","root","","roll_project");
if(!$con){
  echo "connection failled!";
}
//else{echo"connection failled";}
?>